-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 12, 2023 at 01:51 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `task`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`id`, `name`, `email`, `password`, `role`) VALUES
(1, 'Tokyo', 'tokyo@gmail.com', '9083c7c6902370ed72414f77ef25507c', 'admin'),
(2, 'Aishwarya', 'aishwarya66@gmail.com', '8d2954f52da3050fae0df7c2629168c5', 'admin'),
(3, 'Aishwarya', 'aishwarya66@gmail.com', '8d2954f52da3050fae0df7c2629168c5', 'student'),
(4, 'Ahirswy', 'ahirswy@gmail.com', '412fada620fc0851fc6d91dc6668987a', 'admin'),
(5, 'Amulya', 'amulya@gmail.com', '02d71cc7ca80b6cf9a653f3eaccec5a1', 'student'),
(6, 'Amulya', 'amulyaa12@gmail.com', '82b53b8255217508ba9f4e80000c7933', 'admin'),
(7, 'Aairya', 'aishwarya.ms46@gmail.com', 'b19049b79ee40a7fb71876f16fdbfc8f', 'student'),
(8, 'Eleven', 'eleven@gmail.com', '95e923cf0d9ffee593f6aeb38d2b5196', 'admin'),
(9, 'user', 'user@gmail.com', 'b5b73fae0d87d8b4e2573105f8fbe7bc', 'student'),
(10, 'Newuser', 'newuser@gmail.com', 'eb30b6d9cf28ec8e8f394393ad385757', 'student'),
(11, 'Sandy', 'sandy@gmail.com', '92cab14ed467c803792c98ecaf218a7a', 'student');

-- --------------------------------------------------------

--
-- Table structure for table `assign`
--

CREATE TABLE `assign` (
  `id` int(11) NOT NULL,
  `project` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `sdate` text NOT NULL,
  `priority` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `assignedto` varchar(255) NOT NULL,
  `ddate` date NOT NULL,
  `summary` text DEFAULT NULL,
  `steps` text DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assign`
--

INSERT INTO `assign` (`id`, `project`, `category`, `sdate`, `priority`, `name`, `assignedto`, `ddate`, `summary`, `steps`, `image`, `status`) VALUES
(13, 'RainHarwesting', 'shopping', '2023-08-28', 'medium', 'Amulya', 'amulya@gmail.com', '2023-09-05', '-', '-', 'Screenshot_from_2023-09-02_18-08-322.png', 'assigned'),
(15, 'Crud', 'work', '5/9/2023', 'high', 'user', 'user@gmail.com', '2023-09-12', '-', '-', 'Screenshot_from_2023-09-04_17-49-00.png', 'done'),
(18, 'School', 'personal', '2023-08-07', 'medium', 'user', 'user@gmail.com', '2023-08-14', '-', '-', 'Project_Type_Web_Application2.pdf', 'ongoing'),
(19, 'PaymentGateway', 'work', '2023-08-06', 'high', 'Sandy', 'sandy@gmail.com', '2023-08-23', NULL, NULL, '', 'assigned'),
(20, 'PaymentGateway', 'work', '2023-06-06', 'high', 'Amulya', 'amulya@gmail.com', '2023-06-23', NULL, NULL, '', 'assigned'),
(21, 'PaymentGateway', 'work', '2022-08-06', 'medium', 'Aairya', 'aishwarya.ms46@gmail.com', '2022-08-23', NULL, NULL, '', 'assigned'),
(22, 'PaymentGateway', 'work', '2021-10-06', 'high', 'Sandy', 'sandy@gmail.com', '2021-11-23', NULL, NULL, '', 'done'),
(23, 'Chatbot', 'work', '2023-05-10', 'medium', 'Newuser', 'newuser@gmail.com', '2023-05-26', NULL, NULL, '', 'enhance'),
(24, 'design', 'shopping', '2023-05-16', 'low', 'Aishwarya', 'aishwarya66@gmail.com', '2023-05-31', NULL, NULL, '', 'enhance'),
(25, 'Notification', 'work', '2023-09-13', 'medium', 'Amulya', 'amulya@gmail.com', '2023-09-23', NULL, NULL, '', 'assigned');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `doj` date NOT NULL,
  `employeelevel` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `marritalstatus` varchar(255) NOT NULL,
  `nationality` varchar(255) NOT NULL,
  `experience` varchar(255) NOT NULL,
  `emergencyname` varchar(255) NOT NULL,
  `emergencycontact` varchar(255) NOT NULL,
  `relationship` varchar(255) NOT NULL,
  `reportingmanager` varchar(255) NOT NULL,
  `assetid` varchar(255) NOT NULL,
  `assettype` varchar(255) NOT NULL,
  `paddress` varchar(255) DEFAULT NULL,
  `taddress` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id`, `name`, `email`, `contact`, `qualification`, `image`, `department`, `location`, `doj`, `employeelevel`, `gender`, `marritalstatus`, `nationality`, `experience`, `emergencyname`, `emergencycontact`, `relationship`, `reportingmanager`, `assetid`, `assettype`, `paddress`, `taddress`) VALUES
(1, 'Tokyo', 'tokyo@gmail.com', '8767878989', 'BE', 't1.jpg', 'Software Development', 'Banglore', '2022-06-06', 'Intern', 'Female', 'unmarried', 'Indian', '1year ', 'Rio', '7678987876', 'Friend', 'Admin', 'Ai098', 'Desktop', 'kolar1', 'banglore'),
(2, 'Amulya', 'amulya@gmail.com', '7867898909', 'PU', 'Screenshot_from_2023-09-02_18-08-323.png', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', NULL, NULL),
(3, 'user', 'user@gmail.com', '8787656789', 'B.COM', 'bg-01.jpg', 'Software Testing', 'Banglore', '2023-06-09', 'Fresher', 'Male', 'Unmarried', 'Indian', '3months', 'User1', '5656787878', 'Father', 'Tokyo', 'Ai066', 'Desktop', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `phase` varchar(255) NOT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `sdate` date DEFAULT NULL,
  `edate` date DEFAULT NULL,
  `duration` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`id`, `title`, `phase`, `priority`, `sdate`, `edate`, `duration`, `status`, `details`, `image`) VALUES
(1, 'TaskProject', 'phase2', 'product', '0000-00-00', '0000-00-00', '', 'development', 'webapplication', 'Screenshot_from_2023-09-01_18-17-2619.png'),
(4, 'RainHarwesting', 'phase1', 'service', '0000-00-00', '0000-00-00', '', 'requirements', 'environmental', 'Screenshot_from_2023-09-01_18-17-18.png'),
(5, 'Crud', 'phase2', 'product', '0000-00-00', '0000-00-00', '', 'testing', 'undefined', 'Screenshot_from_2023-09-01_18-17-101.png'),
(6, 'NewProject', 'phase1', 'service', '0000-00-00', '0000-00-00', '', 'development', 'Enhancement', 'Screenshot_from_2023-09-02_17-54-35.png'),
(8, 'Chatbot', 'phase2', 'service', '0000-00-00', '0000-00-00', '', 'design', 'healthcare', ''),
(9, 'design', 'phase1', 'product', NULL, NULL, NULL, 'requirements', 'negotiable', ''),
(10, 'PaymentGateway', 'phase1', 'service', NULL, NULL, NULL, 'development', 'Integration', ''),
(12, 'Report', 'phase2', 'product', NULL, NULL, NULL, 'design', 'Softcopy', ''),
(13, 'Shopping Cart', 'phase1', 'service', NULL, NULL, NULL, 'development', 'required', ''),
(14, 'Notification', 'phase1', 'service', NULL, NULL, NULL, 'design', 'Application', ''),
(15, 'Extra Work', 'phase1', 'service', NULL, NULL, NULL, 'design', 'Enhance', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assign`
--
ALTER TABLE `assign`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `assign`
--
ALTER TABLE `assign`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
