<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8"/> 
    <title>Dashboard</title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="https://codingbirdsonline.com/wp-content/uploads/2019/12/cropped-coding-birds-favicon-2-1-192x192.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    
   </head>
<body>
  <!-- SIDEBAR CONTENT -->
 <div style="margin-left:-20px; ">
  <div class="sidebar">
    <div class="logo-details">
      <i class=''></i>
      <span class="logo_name"><a href="<?php echo base_url('index.php/User/index');?>" style="color:White;">FlairBrainz</a></span>
    </a>
    </div>
      <div class="navi">
          <ul>
              <li ><a href="<?php echo base_url('index.php/User/index');?>"><i class="bx bx-home" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Home</span></a></li>
              <li  ><a href="<?php echo base_url('index.php/User/projects');?>"><i class='bx bx-list-ul'  aria-hidden="true"></i><span class="hidden-xs hidden-sm">Workflow</span></a></li>
              <li class="active"><a href="<?php echo base_url('index.php/User/view');?>"><i class="bx bx-bar-chart" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Statistics</span></a></li>
              <li><a href="#" onclick="logout()"> <i class='bx bx-log-out'></i><span class="hidden-xs hidden-sm">Logout</span></a></li>
          </ul>
      </div>
  </div>
  <!-- NAV BAR -->
  <section class="home-section" style="margin-left:0px;">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Dashboard</span>
      </div>
      <div class="profile-details">
      
      <li class="nav-item dropdown show">
						<a class="nav-link dropdown-toggle   waves-effect waves-dark pro-pic" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">

                        <span class="admin_name"><b><?php echo $name?></b></span>
														

							<i class="fa fa-caret-down"></i>

							<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQTHTAJPlLEQwOQG_g-WNP0WayMmnpM-Nq9ZA&usqp=CAU" alt="user" class="rounded-circle" width="31" height="31">
							

						</a>
						<div class="dropdown-menu dropdown-menu-right user-dd animated show">
							<div class="d-flex">

								<a style="margin:auto; padding: 0 0 10px 0" href=""data-toggle="modal" data-target="#profile">
									<div class="changepictureimg-overlay" style="margin:auto;">
									<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQTHTAJPlLEQwOQG_g-WNP0WayMmnpM-Nq9ZA&usqp=CAU"  alt="user" class="rounded-circle changepicture-img-overlay-image" width="150" height="100">
									<div class="changepictureoverlay">
								    <div class="changepicture">Click </div>
								   </div>
								  </div>

								</a>
							</div>
							<a class="dropdown-item" ><a class="nav-link dropdown-toggle" href="" data-toggle="modal" data-target="#myModal"  aria-haspopup="true" aria-expanded="false"> Profile</a>
							<div class="dropdown-divider"></div>
							<a class="dropdown-item" href=""data-toggle="modal" data-target="#password" ><i class="ti-settings m-r-5 m-l-5"></i> Change Password</a>
							<div class="dropdown-divider"></div>
						<a class="dropdown-item" href="#" onclick="logout()"><i class="fa fa-power-off m-r-5 m-l-5"></i> Logout</a>

                        <script>
                        function logout() {
                        var confirmed = confirm("Are you sure you want to logout?");

                        if (confirmed) {
                            // Perform logout actions here
                            // For example, redirect the user to the logout URL:
                            window.location.href = "<?php echo base_url('index.php/Logout/index');?>";
                        }
                        }
                    </script>

						</div>
					</li>
       		
      </div>
    </nav>

    <!-- MAIN CONTENT -->
    <div class="home-content">
              <!-- ALERT MESSAGES -->
           <div class="card-body">
              <div id="alert-div">
                  <?php if($this->session->flashdata('error')){?>
                    <p style="color:red"><?php  echo $this->session->flashdata('error');?></p>	
                    <?php } ?>
                    <p>

                    <?php if($this->session->flashdata('msg')){?>
                    <p style="color:green"><?php  echo $this->session->flashdata('msg');?></p>	
                    <?php } ?>
            
               </div>
                          
                <!-- DISPLAY TASK TABLE -->
                <table class="table table-bordered table-sm" >
                <thead>
                <tr>  
                    <th>Project</th>
                    <th>Category</th> 
                    <th>Start Date </th> 
                    <th>Priority</th>
                    <th>Name</th>
                    <th>Assigned To</th>
                    <th>Due Date</th>
                    <th>Status </th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody id="table">   
               
                </tbody>
            </table>
            

 <!-- UPDATE STATUS MODAL -->
<div class="modal" tabindex="-1" role="dialog" id="update_country">
  <div class="modal-dialog" role="document">
		  <div class="modal-content">
			<div class="modal-header" style="">
			  <h5 class="modal-title"><i class="fa fa-edit"></i>Update </h5>
			</div>
			<div class="modal-body">
                <div class="form-group">
                    <label>project</label>
                </div>
                <div class="form-group">
	
                    <?php $projects = $this->db->select('id,title')->get('project')->result(); ?>

                <select name="project_modal" id="project_modal" class="form-control" disabled>

                    <option value="">Select</option>
                    <?php foreach ($projects as $project): ?>
                    <option value="<?php echo $project->title; ?>"><?php echo $project->title; ?></option>
                    <?php endforeach; ?>

                </select>
                </div>	
                <div class="form-group">
					          <label>Category</label>
				        </div>
                <div class="form-group">	
                    <select name="category_modal" id="category_modal" class="form-control" disabled>
                
                      <option value="work">Work</option>
                      <option value="personal">Personal</option>
                      <option value="shopping">Shopping</option> 
        
                    </select>
                </div>	
                <div class="form-group">
				            <label>Start Date</label>
				        </div>
					
                <div class="form-group">
                    <input type="text" name="sdate_modal" id="sdate_modal" class="form-control" required disabled>
                </div>	
                <div class="form-group">
                    <label>priority</label>
                </div>
					
                <div class="form-group">
					
                    <select id="priority_modal" name="priority_modal" class="form-control" disabled>
                        <option value="">Select</option>
                        <option value="high">High</option>
                        <option value="medium">Medium</option>
                        <option value="low">Low</option> 
                    </select>
                </div>	
                <div class="form-group">
                                <label>Name</label>
				        </div>
					
                <div class="form-group">
				
                    <?php $assigns = $this->db->select('id,name')
                                            ->where('role','student')
                                            ->get('account')
                                            ->result(); ?>

                <select name="name_modal" id="name_modal" class="form-control" disabled>

                    <option value="">Select</option>
                    <?php foreach ($assigns as $assign): ?>
                    <option value="<?php echo $assign->name;?>"><?php echo $assign->name; ?></option>
                    <?php endforeach; ?>

                </select>
                </div>	    
                <div class="form-group">
                                <label>Assigned to</label>
				        </div>
					
                <div class="form-group">
				
                    <?php $assigns = $this->db->select('id,name,email')
                                            ->where('role','student')
                                            ->get('account')
                                            ->result(); ?>

                <select name="assignedto_modal" id="assignedto_modal" class="form-control" disabled>

                    <option value="">Select</option>
                    <?php foreach ($assigns as $assign): ?>
                    <option value="<?php echo $assign->email;?>"><?php echo $assign->name; ?></option>
                    <?php endforeach; ?>

                </select>
                </div>	
                <div class="form-group">
					          <label>Due Date</label>
				        </div>
					
                <div class="form-group">
					          <input type="text" name="ddate_modal" id="ddate_modal" class="form-control" required disabled>
				        </div>	
                <div class="form-group">
					          <label>Summary</label>
				        </div>
                <div class="form-group">
                    <input type="text" name="summary_modal" id="summary_modal" class="form-control" required disabled>     
                </div>	
                <div class="form-group">
					          <label>Description/steps</label>
				        </div>
					
                <div class="form-group">
					        <input type="text" name="steps_modal" id="steps_modal" class="form-control" required>
				        </div>	
                <div class="form-group">
                    <label>Status</label>
                </div>
					
                <div class="form-group">
					
                    <select id="status_modal" name="status_modal" class="form-control">
                    <option value="assigned" data-color="#A0522D">Assigned</option>
                     <option value="ongoing">On Going</option>
                     <option value="done" class="greenText" >Done</option> 
                     <option value="redo" class="redText">Redo</option> 
                     <option value="enhance">Enhance</option> 
                    </select>
                </div>	
				<input type="hidden" name="id_modal" id="id_modal" class="form-control">
			</div>
			<div class="modal-footer" style="padding-bottom:0px !important;text-align:center !important;">
		<p style="text-align:center;float:center;"><button type="submit" id="update_data" class="btn btn-outline-primary" style="">Save</button>
      <button type="button"  class="btn btn-outline-secondary "data-dismiss="modal" >Close</button></p>
		  </div>
		</div>
	</div>
</div>

<!-- AJAX FUNCTION TO DISPLAY TASKS -->
        <script>$.ajax({
		url: "<?php echo site_url("index.php/User/tasks");?>",
		type: "POST",
		cache: false,
		success: function(data){
			//alert(data);
			$('#table').html(data); 
		}
	});

  // AJAX FUNCTION TO UPDATE TASK
  $(function () {
		$('#update_country').on('show.bs.modal', function (event) {
			var button = $(event.relatedTarget); 
			var id = button.data('id');
            // var id = button.data('image');
			var project = button.data('project');
			var category = button.data('category');
			var sdate = button.data('sdate');
			var priority = button.data('priority');
      var name = button.data('name');
            var assignedto = button.data('assignedto');
			var ddate = button.data('ddate');
			var summary = button.data('summary');
			var steps = button.data('steps');
      var status = button.data('status');
			var modal = $(this);
            // modal.find('#image_modal').val(image);
			modal.find('#project_modal').val(project);
			modal.find('#category_modal').val(category);
			modal.find('#sdate_modal').val(sdate);
			modal.find('#priority_modal').val(priority);
      modal.find('#name_modal').val(name);
      modal.find('#assignedto_modal').val(assignedto);
			modal.find('#ddate_modal').val(ddate);
			modal.find('#summary_modal').val(summary);
			modal.find('#steps_modal').val(steps);
      modal.find('#status_modal').val(status);
			modal.find('#id_modal').val(id);
		});
    });
	$(document).on("click", "#update_data", function() { 
		$.ajax({
			url: "<?php echo base_url("index.php/User/updaterecords");?>",
			type: "POST",
			cache: false,
			data:{
				type: 3,
				id: $('#id_modal').val(),
               
				project: $('#project_modal').val(),
				category: $('#category_modal').val(),
				sdate: $('#sdate_modal').val(),
        priority: $('#priority_modal').val(),
        name: $('#name_modal').val(),
				assignedto: $('#assignedto_modal').val(),
				ddate: $('#ddate_modal').val(),
				summary: $('#summary_modal').val(),
				steps: $('#steps_modal').val(),
        status: $('#status_modal').val()
			},
 
	    success: function(response) {
        
        $("#update_data").prop('disabled', false);
        let successHtml = '<div class="alert alert-success" role="alert"><b>Project Updated Successfully</b></div>';
        $("#alert-div").html(successHtml);

        $.ajax({
        url: "<?php echo site_url('index.php/User/tasks'); ?>",
        type: "POST",
        cache: false,
        success: function(data) {
            $('#table').html(data); 
        // 					
        }
        });
        $("#update_country").modal('hide');
        },
        error: function(response) {
        $("#update_data").prop('disabled', false);

        let responseData = JSON.parse(response.responseText);
        console.log(responseData.errors);

        if (typeof responseData.errors !== 'undefined') 
        {
            let errorHtml = '<div class="alert alert-danger" role="alert">' +
                                '<b>Validation Error!</b>' +
                                responseData.errors +
                            '</div>';
            $("#modal-alert-div").html(errorHtml);      
        }
        }
        });
            });



        </script>
        </div>
      </div>  
      </div>
    </div>
  </section>
  </div>
</div>

<!-- JAVASCRIPT FUNCTION FOR SLIDING NAV BAR -->
  <script>
   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
}else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>


<!-- profile details -->

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
          <h5 class="modal-title" id="myModalLabel">Confirm Password</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            
          </div>
          <div class="modal-body">         
              <form id="resetPassword" name="resetPassword" method="post" action="<?php echo base_url();?>index.php/Login/ConfirmPass" onsubmit ='return validate()'>
             <table class="table table-bordered table-hover table-striped">                                      
                        <tbody>
                        <tr>
                        <label class="control-label col-md-12 text-dark">Password <span style="color: red">*</span></label>
                        <td>
                        <input type="password" name="password" id="myInput" style="width:250px" required>
                        <input type="checkbox" onclick="myFunction()">Show 
                        </td>
                        <td><input type = "submit" value="submit" class="button"></td>
                        </tr>
                        </tbody>               
                        </table>
                        </form> 
              <div id="fade" class="black_overlay"></div>                                
						
            </div>  
          <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
          </div>
        </div>
        </div>
      </div>
    </div>

</div>

<!-- JAVASCRIPT FUNCTION FOR PASSWORD TOGGLE -->
<script>
    function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
} 
    </script>


 <!-- change password -->
 <div class="modal fade" id="password" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
          <h5 class="modal-title" id="myModalLabel">Change Password</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            
          </div>
          <div class="modal-body">         
              <form id="resetPassword" name="resetPassword" method="post" action="<?php echo base_url();?>index.php/Login/changepassword" onsubmit ='return validate()'>
             <table class="table table-bordered table-hover table-striped">                                      
                        <tbody>
                        <tr>
                        <div class="form-group">
                        <label > Old Password <span style="color: red">*</span></label>
                        </div>
                        <div class="form-group">
                        <input type="password" name="password" id="myInput" style="width:250px" required>
                       &nbsp;  
                       </div>
                        <div class="form-group">
                        <label class=""> New Password <span style="color: red">*</span></label>
                        </div>
                        <div class="form-group">
                        <input type="password" name="password" id="myInput" style="width:250px" required>
                        &nbsp;  
                        </div>
                        <div class="form-group">
                        <label class=""> Repeat Password <span style="color: red">*</span></label>
                        </div>
                        <div class="form-group">
                        <input type="password" name="password" id="myInput" style="width:250px" required>
                        &nbsp; 
                          </div>
                        <td><input type = "submit" value="submit" class="button"></td>
                        </tr>
                        </tbody>         
                    </table></form> 
                    <div id="fade" class="black_overlay"></div>       
                                         	
            </div>  
           <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
          </div>
        </div>
        </div>
      </div>
    </div>

</div>



</body>
</html>