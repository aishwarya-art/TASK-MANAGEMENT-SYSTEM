<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Profile</title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="https://codingbirdsonline.com/wp-content/uploads/2019/12/cropped-coding-birds-favicon-2-1-192x192.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
   
</head>
<body>
 <!-- SIDEBAR CONTENT -->
 <div style="margin-top:-0px; margin-left:-30px;">
  <div class="sidebar">
 
    <div class="logo-details">
      <i class=''></i>
      <span class="logo_name"><a href="<?php echo base_url('index.php/User/index');?>"style="color:White;">FlairBrainz</a></span>
    </a>
    </div>
        <div class="navi">
          <ul>
          <li ><a href="<?php echo base_url('index.php/User/index');?>"><i class="bx bx-home" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Home</span></a></li>
          <li class="active" ><a href="<?php echo base_url('index.php/User/projects');?>"><i class='bx bx-list-ul'  aria-hidden="true"></i><span class="hidden-xs hidden-sm">Workflow</span></a></li>
          <li><a href="<?php echo base_url('index.php/User/view');?>"><i class="bx bx-bar-chart" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Statistics</span></a></li>
        
          <li><a href="#" onclick="logout()"> <i class='bx bx-log-out'></i><span class="hidden-xs hidden-sm">Logout</span></a></li>
      </ul>
      </div>
  </div>

  <!-- TOP NAV BAR CONTENT -->
  <section class="home-section" style="margin-left:-20px;">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Dashboard</span>
      </div>
     
      <div class="profile-details">
      
      <li class="nav-item dropdown show">
						<a class="nav-link dropdown-toggle   waves-effect waves-dark pro-pic" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">

              <span class="admin_name"><b><?php echo $name?></b></span>
							<i class="fa fa-caret-down"></i>
              <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBhMIBwgWFQkXGBkbGBgYGR4WFRseHxgXHxgeGxUeHSgiHR4tHx4dITEhJS0rLi4uHR8zODMtNygtLi0BCgoKBQUFDgUFDisZExkrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrK//AABEIAMgA+gMBIgACEQEDEQH/xAAcAAEAAgIDAQAAAAAAAAAAAAAABwgFBgIDBAH/xABBEAACAQIDBAUIBwUJAAAAAAAAAQIDBQQGEQcSITEiQVFhkRMyYnGBobHRCBcjQlNUkxQkUsHhJTNDgoOSotLw/8QAFAEBAAAAAAAAAAAAAAAAAAAAAP/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhEDEQA/AJxAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANBzvtSsuVm8LTfl7iv8OD4Rfpz6vVzNf2x7Rqlp1y/Yqn7/JfaTXOCf3Y+k/cYvZvsiWJpxu+botuXSjRber1471R8+PZ4gYKttF2g5qrOnYaEo09eVCnvaeuo9f5H1Zf2uVl5V1cTr310n4b5YbB4PD4HDrD4OhGFFcoxSjFexHoArdPMW1LKn2lwjXdFfiwVWH+9cvE3TJ+2u33GpHC5hoKhXeiVSLbpN9/XH3olqUYzjuyXR8URvn3ZNab/Sli7RTjQuXF8OFOb7JJcvWgJGpVadamqlKacGtU09Vp2pnaV32dZ1uOSb28t5mUlgd7de9zpN8mvRf9SwsJxnHei9YvwA5gAAAAAAAAAAAAAAAAAAAAAAAAAAAABhc4XuGXct17rU504txXbJ8IrxaM0RL9IvHzoZWoYOL4VKur9UI6/FoDUdjWW55qzLVzFeFv0qct7pcVOrLite5c/AsQaNsZt0bfs+wziunUUqj795vT3JG8gAAAAAET7d8oU7lZHfsJT/faPn6c5U+vXvjz9Wp7NhmZpXvK7wGKnrisO1HvcH5j9nFewkTG4anjcHPC1lrTnGUX6mtGV82GV52zaJWtbfRlCpB+unLVfBgWLAAAAAAAAAAAAAAAAAAAAAAAAAAAAACGfpJUZStWDrJdFVJp+txWnwJmNE2zWSV6yLVVGOtelpViuvSPnf8AFsDI7L68a+QMFOL4eSjH2x1T+BtREH0eswwxVkqWKrP7elJyiu2EuenqfxJfAAAAAAPjaS1fIrlso/fNsNTE0/7vXES9jbS+KJm2j5gp5bylXxrl9s4uFNdbnJaLw5+wjX6Odmm54m+Vo9HRUoPteu9N/ACcgAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ThGpBxmtYtNPs0ZzAFas32i47L87xu9pi/wBhlJypv7uj8+nL/wBy0J0ydmu25stixlvqdNab8G+nB9jX8z3X6y4DMFslb7pQUsPLxT6mn1NEB3/Ieatn9yd1y3XnPCLlOnxml2VKfWvFAWPBBWX9u9SnFUcxWvemuc6T0ftpv5m109tuUJw1lKspdnk9X7mBJR5LlcMJbMHLGY+vGGHitZSlwSRE962822lBxs1rqTqdTqNQj4LVmkbmedq2OXlE1gU+vWGHh/2fiwOeb77ctqebadrs9NrBRbVNPlp96pPs4e4sBlix4XLljpWrBroQSTfXJ9cn62YrIeRrbk7A+Twy3sZJLylV+dJ9i7I9xtgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABrOc862jJ+C8tcautdroUo8Zy+S72Qtjdoees6Yt4XLlCdOl/DRWskvSqvl7gLHNpc2fHOL4byK5w2XbQ7gvLYvFaTf4lduXu1Pv1PZ6/PU/wBaXyAmi85Jyve5OdxtNKVR/eXRn4x0NdnsZyXKW8qFRLs8q9COfqez1+ep/rS+Q+p7PX56n+tL5AS1a9muTrXNVKFohKouTqN1PdJ6G20o0aNNU6SUYLqWiS9hXj6ns9fnqf60vkPqez1+ep/rS+QFi1KL5M5Fcnskz5RW/Sxkd7uryTOiV22l5DmpY91XhV+J9tSf+fjp4oCygI62f7VLbmqSwWMiqFz/AIW+hN+g+3uZIoAAAAAAAAAAAAAAAAAAAAAAAAAwecMw4fK9gqXTE8d1aRj1yk/NijOECfSIu9XE3jDWKg+jGO/JdspvSPuXvAweUMt3TajmWpdr1Vl+xJ/aS7eynDs4eBYez2jAWTAxwVrw0adBdUVp7W+t97PBkmw0ct5ZoW2nHpRinN9s3xk37TPgAAAAAAAADqrUqdek6VaClBrimtU13o7QBA21jZpG003mLLFNxpRe9Upx+56cOxdq6jc9j2d5Zqs7wlwn/adHTefXOPVP19T/AKkhVqVOvSdKrDWDTTT4pp80VutUJZA2y/skHphXV3P9Op5vhqvACyoAAAAAAAAAAAAAAAAAAAAAAABBefMp3u6bXKWLpW+csC5UHv6awUYab2r6uTJ0AAAAAAAAAAAAAAAIN2t5TvVx2g4fH2u3znRlGkt6K1inGXHefVw0JyAHGGu50uZyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//Z" alt="user" class="rounded-circle" width="41" height="41">

						</a>
						
            <div class="dropdown-menu dropdown-menu-right user-dd animated show">
							<div class="d-flex">
							</div>
							<div class="dropdown-divider"></div>
						  <a class="dropdown-item" href="#" onclick="logout()"><i class="fa fa-power-off m-r-5 m-l-5"></i> Logout</a>

                    <!-- JAVASCRIPT FUNCTION FOR LOGOUT CONFIRMATION -->
                    <script>
                        function logout() {
                        var confirmed = confirm("Are you sure you want to logout?");

                        if (confirmed) {
                            // Perform logout actions here
                            // For example, redirect the user to the logout URL:
                            window.location.href = "<?php echo base_url('index.php/Logout/index');?>";
                        }
                        }
                    </script>

						</div>
					</li>		
      </div>
    </nav>

    <!-- MAIN HOME CONTENT -->
<div class="home-content">
    <div class="welcome-text"style="margin-top:-50px;" >

   
        <div id="alert-div">
             
          <?php if($this->session->flashdata('error')){?>
            <p style="color:red"><?php  echo $this->session->flashdata('error');?></p>	
            <?php } ?>
            <p>

            <?php if($this->session->flashdata('msg')){?>
            <p style="color:green"><?php  echo $this->session->flashdata('msg');?></p>	
            <?php } ?>
        </div> 

                 
  <!-- DISPLAY PROFIULE DETAILS TABLE -->
  <h2 class="text-center mt-5 mb-3"></h2>
  <div class="card">
  		<div class="card-header">
        <button class="btn btn-outline-primary" onclick="createProject()">Profile Details</button>
        </div>
		    <div class="card-body">
           <table class="table table-bordered">
           <tbody id="table">
      
      </tbody>
    </table>
  </div> 

<!-- INSTER PROFILE DETAILS MODAL -->
<div class="modal" tabindex="-1" role="dialog" id="form-modal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Enter Profile Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <div id="modal-alert-div">
             
        </div>
        <form enctype="multipart/form-data">
             <input type="hidden" name="update_id" id="update_id"> 
             <div class="form-group">
			        <label>Select Profile Photo</label> <span style="color: red">*</span> <br>
              <input type="file" name="user_image" id="user_image" />  
              <span id="user_uploaded_image"></span> <br>
            </div>            
             <div class="form-group">
                <label for="name">Enter Registered Name<span style="color: red">*</span></label>
                <input type="text" class="form-control" id="name" name="name">
            </div>
            <div class="form-group">
                <label for="description">Enter Registered Email<span style="color: red">*</span></label>
				        <input type="text" class="form-control" id="email" name="email">   
            </div>
            <div class="form-group">
                <label for="phone">Contact Number<span style="color: red">*</span></label>
                <input type="text" class="form-control" id="contact" name="contact">
            </div>
            <div class="form-group">
                <label for="phone">Qualification<span style="color: red">*</span></label>
                <input type="text" class="form-control" id="qualification" name="qualification">
            </div>
            <div class="form-group">
                <label for="city">Department<span style="color: red">*</span></label>
				        <input type="text" class="form-control" id="department" name="department"> 
            </div>
            <div class="form-group">
                <label for="city">Date of Joining<span style="color: red">*</span></label>
				        <input type="date" class="form-control" id="doj" name="doj"> 
            </div>
            <div class="form-group">
                <label for="city">Reporting Manager<span style="color: red">*</span></label>
				        <input type="text" class="form-control" id="reportingmanager" name="reportingmanager"> 
            </div>
            <div class="form-group">
                <label for="city">Asset ID<span style="color: red">*</span></label>
				        <input type="text" class="form-control" id="assetid" name="assetid"> 
            </div>
            <div class="form-group">
                <label for="city">Asset Type <span style="color: red">*</span></label>
				        <input type="text" class="form-control" id="assettype" name="assettype"> 
            </div>
            <div class="form-group">
                <label for="city">Employee Level<span style="color: red">*</span></label>
				        <input type="text" class="form-control" id="employeelevel" name="employeelevel"> 
            </div>
            <div class="form-group">
                <label for="city">Location<span style="color: red">*</span></label>
				        <input type="text" class="form-control" id="location" name="location"> 
            </div>
            <div class="form-group">
                <label for="city">Gender<span style="color: red">*</span></label>
				        <input type="text" class="form-control" id="gender" name="gender"> 
            </div>
            <div class="form-group">
                <label for="city">Marrital Status<span style="color: red">*</span></label>
				        <input type="text" class="form-control" id="marritalstatus" name="marritalstatus">
            </div>
            <div class="form-group">
                <label for="city">Nationality<span style="color: red">*</span></label>
				        <input type="text" class="form-control" id="nationality" name="nationality"> 
            </div>
            <div class="form-group">
                <label for="city">Experience<span style="color: red">*</span></label>
				        <input type="text" class="form-control" id="experience" name="experience"> 
            </div>
            <div class="form-group">
                <label for="city">Emergency Name<span style="color: red">*</span></label>
				        <input type="text" class="form-control" id="emergencyname" name="emergencyname"> 
            </div>
            <div class="form-group">
                <label for="city">Emergency Contact<span style="color: red">*</span></label>
				        <input type="text" class="form-control" id="emergencycontact" name="emergencycontact"> 
            </div>
            <div class="form-group">
                <label for="city">Relationship<span style="color: red">*</span></label>
				        <input type="text" class="form-control" id="relationship" name="relationship"> 
            </div>
            <button type="submit" class="btn btn-outline-primary" id="save-project-btn">Update Profile</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> 
        </form>
      </div>
    </div>
  </div>
</div>


   

<script>

//AJAX FUNCTION TO DISPLAY THE PROFILE DETAILS
	$.ajax({
		url: "<?php echo site_url("index.php/User/viewajax");?>",
		type: "POST",
		cache: false,
		success: function(data){
			//alert(data);
			$('#table').html(data); 
		}
	});


  $(function () {
		$('#update_country').on('show.bs.modal', function (event) {
			var button = $(event.relatedTarget); 
			var id = button.data('id');
            // var id = button.data('image');
			var name = button.data('name');
			var email = button.data('email');
			var phone = button.data('phone');
			var city = button.data('city');
			var modal = $(this);
            // modal.find('#image_modal').val(image);
			modal.find('#name_modal').val(name);
			modal.find('#email_modal').val(email);
			modal.find('#phone_modal').val(phone);
			modal.find('#city_modal').val(city);
			modal.find('#id_modal').val(id);
		});
    });
	$(document).on("click", "#update_data", function() { 
		$.ajax({
			url: "<?php echo base_url("index.php/Ajax/updaterecords");?>",
			type: "POST",
			cache: false,
			data:{
				type: 3,
				id: $('#id_modal').val(),
                // image: $('#image_modal').val(),
				name: $('#name_modal').val(),
				email: $('#email_modal').val(),
				phone: $('#phone_modal').val(),
				city: $('#city_modal').val()
			},
			

	success: function(response) {
 
 $("#update_data").prop('disabled', false);
 let successHtml = '<div class="alert alert-success" role="alert"><b>Project Updated Successfully</b></div>';
 $("#alert-div").html(successHtml);

 $.ajax({
  url: "<?php echo site_url('index.php/User/viewajax'); ?>",
 type: "POST",
 cache: false,
  success: function(data) {
	  $('#table').html(data);
 }
});
 $("#update_country").modal('hide');
},
error: function(response) {
 $("#update_data").prop('disabled', false);

 let responseData = JSON.parse(response.responseText);
 console.log(responseData.errors);

 if (typeof responseData.errors !== 'undefined') 
 {
	 let errorHtml = '<div class="alert alert-danger" role="alert">' +
						 '<b>Validation Error!</b>' +
						 responseData.errors +
					 '</div>';
	 $("#modal-alert-div").html(errorHtml);      
 }
}
});
	});



function updatePageContent() {
    $.ajax({
        url: "<?php echo site_url('index.php/User/viewajax'); ?>",
        type: "POST",
        cache: false,
        success: function(data) {
            $('#table').html(data); 
        }
    });
}



	
//AJAX FUNCTION TO INSERT THE PROFILE DETAILS
	function createProject()
    {
        $("#alert-div").html("");
        $("#modal-alert-div").html("");
        $("#update_id").val("");
        $("#name").val("");
        $("#description").val("");
        $("#form-modal").modal('show');
		  
    }
 

	$("#save-project-btn").click(function(event){
        event.preventDefault();
        if($("#update_id").val() == null || $("#update_id").val() == "")
        {
            storeProject();
        } else {
            updateProject();
        }
    })
 
</script>
<script>
    function storeProject() {
   
    $("#save-project-btn").click(function(event){
        event.preventDefault();
        $("#save-project-btn").prop('disabled', true);
    
    let formData = new FormData();
    formData.append('name', $("#name").val());
    formData.append('email', $("#email").val());
    formData.append('contact', $("#contact").val());
    formData.append('qualification', $("#qualification").val());
    formData.append('department', $("#department").val());
    formData.append('location', $("#location").val());
    formData.append('doj', $("#doj").val());
    formData.append('employeelevel', $("#employeelevel").val());
    formData.append('gender', $("#gender").val());
    formData.append('marritalstatus', $("#marritalstatus").val());
    formData.append('nationality', $("#nationality").val());
    formData.append('experience', $("#experience").val());
    formData.append('emergencyname', $("#emergencyname").val());
    formData.append('emergencycontact', $("#emergencycontact").val());
    formData.append('relationship', $("#relationship").val());
    formData.append('reportingmanager', $("#reportingmanager").val());
    formData.append('assetid', $("#assetid").val());
    formData.append('assettype', $("#assettype").val());
    formData.append('user_image', $("#user_image")[0].files[0]);

    $.ajax({
        url: "<?php echo site_url("index.php/User/store"); ?>",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
            
            $("#save-project-btn").prop('disabled', false);
                let successHtml = '<div class="alert alert-success" role="alert"><b>Project Created Successfully</b></div>';
                $("#alert-div").html(successHtml);
                $("#name").val("");
                $("#email").val("");
                $("#contact").val("");
				        $("#qualification").val("");
                $("#department").val("");
				        $("#location").val("");
                $("#doj").val("");
                $("#employeelevel").val("");
                $("#gender").val("");
				        $("#marritalstatus").val("");
                $("#nationality").val("");
				        $("#experience").val("");
                $("#emergencyname").val("");
                $("#emergencycontact").val("");
				        $("#relationship").val("");
                $("#reportingmanager").val("");
                $("#assetid").val("");
                $("#assettype").val("");
                
				
            
            if (response.image_url) {
                let imageUrl = response.image_url;
                let imageHtml = `<img src="${imageUrl}" alt="User Image" width="50">`;
                $("#user_uploaded_image").html(imageHtml);
            }
           
            $.ajax({
                 url: "<?php echo site_url('index.php/User/viewajax'); ?>",
                type: "POST",
                cache: false,
                 success: function(data) {
                     $('#table').html(data); 
 					
                }
            });
                $("#form-modal").modal('hide');
            },
            
           
        error: function(response) {
                $("#save-project-btn").prop('disabled', false);
            
                let responseData = JSON.parse(response.responseText);
                console.log(responseData.errors);
 
                if (typeof responseData.errors !== 'undefined') 
                {
                    let errorHtml = '<div class="alert alert-danger" role="alert">' +
                                        '<b>Validation Error!</b>' +
                                        responseData.errors +
                                    '</div>';
                    $("#modal-alert-div").html(errorHtml);      
                }
            }
        });
	});
    }
    

    </script>

      </div>
    </p>
    </div>
  </div>  
  </div>
  </div>
</section>
</div>
</div>

    <!-- SIDEBAR SLIDING JAVASCRIPT FUNCTION -->
      <script>
          let sidebar = document.querySelector(".sidebar");
          let sidebarBtn = document.querySelector(".sidebarBtn");
          sidebarBtn.onclick = function()
           {
            sidebar.classList.toggle("active");
            if(sidebar.classList.contains("active")){
            sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
           }
           else
            sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
          }
    </script>




</div>
</body>
</html>