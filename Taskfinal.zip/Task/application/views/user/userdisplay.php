<html>  
 <head>  
   <title>Project Display</title>  
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
      <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
      <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
      <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />  
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
      <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="icon" href="https://codingbirdsonline.com/wp-content/uploads/2019/12/cropped-coding-birds-favicon-2-1-192x192.png" type="image/x-icon"> 
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    
</head>
<body>
<!-- SIDEBAR DETAILS -->
  <div class="sidebar">
    <div class="logo-details">
   
      <i class=''></i>
      <span class="logo_name"><a href="<?php echo base_url('index.php/User/index');?>" style="color:White;">FlairBrainz</a></span>
    </a>
    </div>
    <div class="navi">
      <ul>
          <li ><a href="<?php echo base_url('index.php/User/index');?>"><i class="bx bx-home" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Home</span></a></li>
          <li class="active" ><a href="<?php echo base_url('index.php/User/projects');?>"><i class='bx bx-list-ul'  aria-hidden="true"></i><span class="hidden-xs hidden-sm">Workflow</span></a></li>
          <li><a href="<?php echo base_url('index.php/User/view');?>"><i class="bx bx-bar-chart" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Statistics</span></a></li>
          <li><a href="#" onclick="logout()"> <i class='bx bx-log-out'></i><span class="hidden-xs hidden-sm">Logout</span></a></li>
      </ul>
      </div>
  </div>

          <!-- JAVASCRIPT LOGOUT CONFIRMATION -->
          <script>
              function logout() {
              var confirmed = confirm("Are you sure you want to logout?");

              if (confirmed) {
                  // Perform logout actions here
                  // For example, redirect the user to the logout URL:
                  window.location.href = "<?php echo base_url('index.php/Logout/index');?>";
              }
              }
          </script>

<!-- TOP NAV BAR -->
  <section class="home-section" >
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Dashboard</span>
      </div>

      <div class="profile-details">
      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQTHTAJPlLEQwOQG_g-WNP0WayMmnpM-Nq9ZA&usqp=CAU" alt="user" class="rounded-circle" width="31" height="31">
        <a  href="" data-toggle="modal" data-target="#myModal"  aria-haspopup="true" aria-expanded="false"><span class="admin_name"><b><?php echo $name?></b></span></a>
        <i class='bx bx-chevron-down' ></i>
      </div>
    </nav>

    <!-- MAIN HOME CONTENT -->
    <div class="home-content">
    
              <!-- ALERT MESSAGE BOX TO DISPLAY ERRORS AND SUCCESS -->
              <div id="alert-div">
              
              <?php if($this->session->flashdata('error')){?>
                    <p style="color:red"><?php  echo $this->session->flashdata('error');?></p>	
                    <?php } ?> 
                    <p>

                    <?php if($this->session->flashdata('msg')){?>
                    <p style="color:green"><?php  echo $this->session->flashdata('msg');?></p>	
                    <?php } ?>
               </div>
                   
                   
               
            <!-- PROJECTS LISTING TABLE -->
           <div class="table-responsive" style="font-size:18px;">  
                <br />  
              
                <table id="user_data" class="table table-bordered table-striped">  
                     <thead>  
                          <tr>  
                               <th width="10%">Project ID</th>  
                               <th width="35%">Project Title</th>  
                               <th width="35%">Phase</th>  
                                
                               <th width="10%">Type</th> 
                               <th width="10%">Status</th>
                               <th width="10%">Description</th> 
                              
                          </tr>  
                     </thead>  
                </table>  
           </div>  
      </div>   
 
 <!-- AJAX REQUEST TO DIAPLY PROJECTS WITH SORT, SEARCH AND PAGINATION OPTIONS -->
 <script type="text/javascript" language="javascript" >  
 $(document).ready(function(){  
      $('#add_button').click(function(){  
           $('#user_form')[0].reset();  
           $('.modal-title').text("Add User");  
           $('#action').val("Add");  
           $('#user_uploaded_image').html('');  
      })  
      var dataTable = $('#user_data').DataTable({  
           "processing":true,  
           "serverSide":true,  
           "order":[],  
           "ajax":{  
                url:"<?php echo base_url("index.php/User/fetch_user"); ?>",  
                type:"POST"  
           },  
           "columnDefs":[  
                {  
                     "targets":[0, 3, 4],  
                     "orderable":false,  
                },  
           ],  
      });  
     
});
 </script>  

<!-- JAVASCRIPT FUNCTION FOR SLIDING SIDE BAR -->
<script>
   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
}else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>


<!-- profile details PASSWORD CONFIRMATION-->

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
          <h5 class="modal-title" id="myModalLabel">Confirm Password</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            
          </div>
          <div class="modal-body">         
              <form id="resetPassword" name="resetPassword" method="post" action="<?php echo base_url();?>index.php/Login/ConfirmPass" onsubmit ='return validate()'>
                <table class="table table-bordered table-hover table-striped">                                      
                      <tbody>
                      <tr>
                        <label class="control-label col-md-12 text-dark">Password <span style="color: red">*</span></label>
                      <td>
                        <input type="password" name="password" id="myInput" style="width:250px" required>
                        <input type="checkbox" onclick="myFunction()">Show 
                      </td>
                      <td>
                      <input type = "submit" value="submit" class="button"></td>
                      </tr>
                       
                      </tbody>               
                    
                  </table>
                </form> 
                <div id="fade" class="black_overlay"></div>       
            </div>  
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
          </div>
        </div>
        </div>
      </div>
    </div>

</div>

      <!-- JAVASCIPT FUNCTION TO TOGGLE BETWEEN SHOW PASSWORD AND HIDE PASSWORD -->
        <script>
        function myFunction() {
            var x = document.getElementById("myInput");
            if (x.type === "password") {
              x.type = "text";
            } else {
              x.type = "password";
            }
          } 
        </script>

</body>
</html>
 


