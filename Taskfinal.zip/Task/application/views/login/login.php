<!DOCTYPE html>
<html lang="en">
<head> 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="icon" href="https://codingbirdsonline.com/wp-content/uploads/2019/12/cropped-coding-birds-favicon-2-1-192x192.png" type="image/x-icon">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
       
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
   
</head>
<body>

<section class="background-radial-gradient overflow-hidden">
  <style>
    .background-radial-gradient {
      background-color: hsl(218, 41%, 15%);
      background-image: radial-gradient(650px circle at 0% 0%,
          hsl(218, 41%, 35%) 15%,
          hsl(218, 41%, 30%) 35%,
          hsl(218, 41%, 20%) 75%,
          hsl(218, 41%, 19%) 80%,
          transparent 100%),
        radial-gradient(1250px circle at 100% 100%,
          hsl(218, 41%, 45%) 15%,
          hsl(218, 41%, 30%) 35%,
          hsl(218, 41%, 20%) 75%,
          hsl(218, 41%, 19%) 80%,
          transparent 100%);
    }

    #radius-shape-1 {
      height: 220px;
      width: 220px;
      top: -60px;
      left: -130px;
      background: radial-gradient(#44006b, #ad1fff);
      overflow: hidden;
    }

    #radius-shape-2 {
      border-radius: 38% 62% 63% 37% / 70% 33% 67% 30%;
      bottom: -60px;
      right: -110px;
      width: 300px;
      height: 300px;
      background: radial-gradient(#44006b, #ad1fff);
      overflow: hidden;
    }

    .bg-glass {
      background-color: hsla(0, 0%, 100%, 0.9) !important;
      backdrop-filter: saturate(200%) blur(25px);
    }
  </style>

  <div class="container px-4 py-5 px-md-5 text-center text-lg-start my-5" style="font-family: Arial">
    <div class="row gx-lg-5 align-items-center mb-5">
      <div class="col-lg-6 mb-5 mb-lg-0" style="z-index: 10">
        <h1 class="my-5 display-5 fw-bold ls-tight" style="color: hsl(218, 81%, 95%)">
          FlairBrainz<br/>
         <span style="color: hsl(218, 81%, 75%);font-family:Arial;">Task Management System</span>
        </h1>
        <p class="mb-4 opacity-70" style="color: hsl(218, 81%, 85%)">
         
        </p>
      </div>

      <div class="col-lg-6 mb-5 mb-lg-0 position-relative">
        <div id="radius-shape-1" class="position-absolute rounded-circle shadow-5-strong"></div>
        <div id="radius-shape-2" class="position-absolute shadow-5-strong"></div>

        <div class="card bg-glass">
          <div class="card-body px-4 py-5 px-md-5">
         
               <h4 class="text-uppercase text-center mb-5"><?php echo $this->lang->line('login'); ?></h4>
            <select class="form-control" onchange="javascript:window.location.href='<?php echo base_url(); ?>index.php/LanguageSwitcher/switchLang/'+this.value;">        
                <option value="english" <?php if($this->session->userdata('site_lang') == 'english') echo 'selected="selected"'; ?>>English</option>
                
                <option value="kannada" <?php if($this->session->userdata('site_lang') == 'kannada') echo 'selected="selected"'; ?>>Kannada</option>     
                
            </select>
            <br>
            
                    <!-- Form open for login page -->
                    <?php echo form_open('index.php/Login',['name'=>'userregistration','autocomplete'=>'off']);?>
                    
                   
                    <div class="form-outline mb-4">

                    <!-- Display errors and success message -->
                    <?php if($this->session->flashdata('error')){?>
                    <p style="color:red"><?php  echo $this->session->flashdata('error');?></p>	
                    <?php } ?>

                    <?php if($this->session->flashdata('msg')){?>
                    <p style="color:green"><?php  echo $this->session->flashdata('msg');?></p>	
                    <?php } ?>
                     <label style="margin-left:-320px;"><?php echo $this->lang->line('email'); ?></label> 
                    <?php echo form_input(['name'=>'email','class'=>'form-control','value'=>set_value('email'),'placeholder'=>'']);?>
                    
                    <?php echo form_error('email',"<div style='color:red'>","</div>");?>       	
                    </div>
                    <div class="form-outline mb-4">
                    <label style="margin-left:-300px;"><?php echo $this->lang->line('password'); ?></label> 
                    <?php echo form_password(['name'=>'password','class'=>'form-control','value'=>set_value('password'),'placeholder'=>'']);?>
                    <?php echo form_error('password',"<div style='color:red'>","</div>");?>  
                    </div>
                   
                    <div class="form-outline mb-4">
                    <?php echo form_submit(['name'=>'insert','value'=>"Submit",'class'=>'btn btn-primary btn-block mb-4']);?>
                    </div>
                    </form>
                    <?php echo form_close();?>
                    
                    <div><p class="text-center text-muted mt-5 mb-0 "><?php echo $this->lang->line('account'); ?> <a href="<?php echo site_url('index.php/Account');?>"
                    class="fw-bold text-body"><u><b><?php echo $this->lang->line('register'); ?></b></u></a></p></div>
                    <div><p class="text-center text-muted mt-5 mb-0 "><?php echo $this->lang->line('forgotpassword'); ?>
                  
                   <button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#myModal" class="btn btn-info btn"><?php echo $this->lang->line('reset'); ?></button>
                   </p></div>

                </div> 
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
        
      <!-- Forgot Password Modal -->
      <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="myModalLabel">Reset your password</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button> 
                </div>
                <div class="modal-body">         
                  <form id="resetPassword" name="resetPassword" method="post" action="<?php echo base_url();?>index.php/Login/ForgotPassword" onsubmit ='return validate()'>
                  <table class="table table-bordered table-hover table-striped">                                      
                      <tbody>
                      <tr>
                      Enter Email:
                      <td>
                      <input type="email" name="email" id="email" style="width:250px" required>
                      </td>
                      <td>
                      <input type = "submit" value="submit" class="button"></td>
                      </tr>
                    
                      </tbody>              
                      </table>
                  </form>

                  <div id="fade" class="black_overlay"></div>       
                                
                </div>  
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              
                </div>
              </div>
            </div>
          </div>


</body>
</html>
                    