<html>  
 <head>   
   <title>Task</title>  
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
      <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
      <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
      <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />  
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
      <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="icon" href="https://codingbirdsonline.com/wp-content/uploads/2019/12/cropped-coding-birds-favicon-2-1-192x192.png" type="image/x-icon">
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

   </head>
<body>

     <!-- LOGOUT CONFIRMATION JAVASCRIPT -->
      <script>
            function logout() {
            var confirmed = confirm("<?php echo $this->lang->line('logoutconfirm'); ?>");

            if (confirmed) {
                
                window.location.href = "<?php echo base_url('index.php/Logout/index');?>";
            }
            }
        </script>
 
 <div>
  <div class="sidebar">
 
    <div class="logo-details">
   
      <i class=''></i>
      <span class="logo_name"><a href="<?php echo base_url('index.php/Dashboard/dashboard');?>" style="color:White;">FlairBrainz</a></span>
    </a>
    </div>
      
      <div class="navi">
          <ul>
              <li ><a href="<?php echo base_url('index.php/Dashboard/dashboard');?>"><i class="bx bx-home" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Home</span></a></li>
              <li><a href="<?php echo base_url('index.php/Ajax/index');?>"><i class='bx bx-list-ul'  aria-hidden="true"></i><span class="hidden-xs hidden-sm">Workflow</span></a></li>
              <li class="active"><a href="<?php echo base_url('index.php/Task/index');?>"><i class="bx bx-bar-chart" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Statistics</span></a></li>
              <li><a href="<?php echo base_url('index.php/Dashboard/calendar');?>"><i class="bx bx-calendar" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Calender</span></a></li>
              <li><a href="#" onclick="logout()"> <i class='bx bx-log-out'></i><span class="hidden-xs hidden-sm">Logout</span></a></li>
          </ul>
      </div>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Dashboard</span>
      </div> 

      <div class="profile-details">
          <a  href="" data-toggle="modal" data-target="#"  aria-haspopup="true" aria-expanded="false"><span class="admin_name"><b><?php echo $name?></b></span></a>
          <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBhMIBwgWFQkXGBkbGBgYGR4WFRseHxgXHxgeGxUeHSgiHR4tHx4dITEhJS0rLi4uHR8zODMtNygtLi0BCgoKBQUFDgUFDisZExkrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrK//AABEIAMgA+gMBIgACEQEDEQH/xAAcAAEAAgIDAQAAAAAAAAAAAAAABwgFBgIDBAH/xABBEAACAQIDBAUIBwUJAAAAAAAAAQIDBQQGEQcSITEiQVFhkRMyYnGBobHRCBcjQlNUkxQkUsHhJTNDgoOSotLw/8QAFAEBAAAAAAAAAAAAAAAAAAAAAP/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhEDEQA/AJxAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANBzvtSsuVm8LTfl7iv8OD4Rfpz6vVzNf2x7Rqlp1y/Yqn7/JfaTXOCf3Y+k/cYvZvsiWJpxu+botuXSjRber1471R8+PZ4gYKttF2g5qrOnYaEo09eVCnvaeuo9f5H1Zf2uVl5V1cTr310n4b5YbB4PD4HDrD4OhGFFcoxSjFexHoArdPMW1LKn2lwjXdFfiwVWH+9cvE3TJ+2u33GpHC5hoKhXeiVSLbpN9/XH3olqUYzjuyXR8URvn3ZNab/Sli7RTjQuXF8OFOb7JJcvWgJGpVadamqlKacGtU09Vp2pnaV32dZ1uOSb28t5mUlgd7de9zpN8mvRf9SwsJxnHei9YvwA5gAAAAAAAAAAAAAAAAAAAAAAAAAAAABhc4XuGXct17rU504txXbJ8IrxaM0RL9IvHzoZWoYOL4VKur9UI6/FoDUdjWW55qzLVzFeFv0qct7pcVOrLite5c/AsQaNsZt0bfs+wziunUUqj795vT3JG8gAAAAAET7d8oU7lZHfsJT/faPn6c5U+vXvjz9Wp7NhmZpXvK7wGKnrisO1HvcH5j9nFewkTG4anjcHPC1lrTnGUX6mtGV82GV52zaJWtbfRlCpB+unLVfBgWLAAAAAAAAAAAAAAAAAAAAAAAAAAAAACGfpJUZStWDrJdFVJp+txWnwJmNE2zWSV6yLVVGOtelpViuvSPnf8AFsDI7L68a+QMFOL4eSjH2x1T+BtREH0eswwxVkqWKrP7elJyiu2EuenqfxJfAAAAAAPjaS1fIrlso/fNsNTE0/7vXES9jbS+KJm2j5gp5bylXxrl9s4uFNdbnJaLw5+wjX6Odmm54m+Vo9HRUoPteu9N/ACcgAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ThGpBxmtYtNPs0ZzAFas32i47L87xu9pi/wBhlJypv7uj8+nL/wBy0J0ydmu25stixlvqdNab8G+nB9jX8z3X6y4DMFslb7pQUsPLxT6mn1NEB3/Ieatn9yd1y3XnPCLlOnxml2VKfWvFAWPBBWX9u9SnFUcxWvemuc6T0ftpv5m109tuUJw1lKspdnk9X7mBJR5LlcMJbMHLGY+vGGHitZSlwSRE962822lBxs1rqTqdTqNQj4LVmkbmedq2OXlE1gU+vWGHh/2fiwOeb77ctqebadrs9NrBRbVNPlp96pPs4e4sBlix4XLljpWrBroQSTfXJ9cn62YrIeRrbk7A+Twy3sZJLylV+dJ9i7I9xtgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABrOc862jJ+C8tcautdroUo8Zy+S72Qtjdoees6Yt4XLlCdOl/DRWskvSqvl7gLHNpc2fHOL4byK5w2XbQ7gvLYvFaTf4lduXu1Pv1PZ6/PU/wBaXyAmi85Jyve5OdxtNKVR/eXRn4x0NdnsZyXKW8qFRLs8q9COfqez1+ep/rS+Q+p7PX56n+tL5AS1a9muTrXNVKFohKouTqN1PdJ6G20o0aNNU6SUYLqWiS9hXj6ns9fnqf60vkPqez1+ep/rS+QFi1KL5M5Fcnskz5RW/Sxkd7uryTOiV22l5DmpY91XhV+J9tSf+fjp4oCygI62f7VLbmqSwWMiqFz/AIW+hN+g+3uZIoAAAAAAAAAAAAAAAAAAAAAAAAAwecMw4fK9gqXTE8d1aRj1yk/NijOECfSIu9XE3jDWKg+jGO/JdspvSPuXvAweUMt3TajmWpdr1Vl+xJ/aS7eynDs4eBYez2jAWTAxwVrw0adBdUVp7W+t97PBkmw0ct5ZoW2nHpRinN9s3xk37TPgAAAAAAAADqrUqdek6VaClBrimtU13o7QBA21jZpG003mLLFNxpRe9Upx+56cOxdq6jc9j2d5Zqs7wlwn/adHTefXOPVP19T/AKkhVqVOvSdKrDWDTTT4pp80VutUJZA2y/skHphXV3P9Op5vhqvACyoAAAAAAAAAAAAAAAAAAAAAAABBefMp3u6bXKWLpW+csC5UHv6awUYab2r6uTJ0AAAAAAAAAAAAAAAIN2t5TvVx2g4fH2u3znRlGkt6K1inGXHefVw0JyAHGGu50uZyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//Z" alt="user" class="rounded-circle" width="41" height="41">
      </div> 
    </nav>
    <div class="home-content">
              
              <div id="alert-div">
             
                  <?php if($this->session->flashdata('error')){?>
                    <p style="color:red"><?php  echo $this->session->flashdata('error');?></p>	
                    <?php } ?>
                    <p>

                    <?php if($this->session->flashdata('msg')){?>
                    <p style="color:green"><?php  echo $this->session->flashdata('msg');?></p>	
                    <?php } ?>
               </div>
                   
           <div class="table-responsive">   
              <a class="btn btn-secondary" href="<?php echo base_url('index.php/Task/add') ?>">Create New</a>
                <br /><br />  
                <table id="user_data" class="table table-bordered table-striped">  
                     <thead>  
                          <tr>  
                               <th >ID</th>  
                               <th >Project </th>  
                               <th >Category</th>  
                               <th>Start Date </th> 
                                <th>Priority</th>
                                <th>Name</th>
                                <th>Assigned To</th>
                                <th>Due Date</th>
                                <th>Status </th>
                                <th>Update</th>
                                <th>Delete</th>
                              <th>Mail</th>
                          </tr>  
                     </thead>  
                </table>  
           </div>  
      </div>  

      
      <script>
        let sidebar = document.querySelector(".sidebar");
      let sidebarBtn = document.querySelector(".sidebarBtn");
      sidebarBtn.onclick = function() {
        sidebar.classList.toggle("active");
        if(sidebar.classList.contains("active")){
        sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
      }else
        sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
      }
      </script>


      <div class="modal fade" id="mymail" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
          <h5 class="modal-title" id="myModalLabel">Send Mail about assigned project</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            
          </div>
          <div class="modal-body">         
              <form id="resetPassword" name="resetPassword" method="post" action="<?php echo base_url();?>index.php/Task/sendmail" onsubmit ='return validate()'>
             <table class="table table-bordered table-hover table-striped">                                      
                        <tbody>
                        <tr>
                        Enter Email:
                        <td>
                    <input type="email" name="email" id="email" style="width:250px" required>
                     </td>
                        <td><input type = "submit" value="submit" class="button"></td>
                        </tr>
                       
                        </tbody>               </table></form> 
                                         <div id="fade" class="black_overlay"></div>       
                          
            </div>  
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
          </div>
        </div>
      </div>
    </div>
   
  
 <div id="userModal" class="modal fade">  
      <div class="modal-dialog">  
           <form method="post" id="user_form">  
                <div class="modal-content">  
                     <div class="modal-header">  
                          <button type="button" class="close" data-dismiss="modal">&times;</button>  
                          <h4 class="modal-title">Edit User</h4>  
                     </div>  
                     <div class="modal-body">  
                          

                          <div class="form-group">
                    <label>project</label>
                </div>
                <div class="form-group">
	
                    <?php $projects = $this->db->select('id,title')->get('project')->result(); ?>

                <select name="project" id="project" class="form-control">

                    <option value="">Select</option>
                    <?php foreach ($projects as $project): ?>
                    <option value="<?php echo $project->title; ?>"><?php echo $project->title; ?></option>
                    <?php endforeach; ?>

                </select>
                </div>	
                <div class="form-group">
					<label>Category</label>
				</div>
                <div class="form-group">	
                    <select name="category" id="category" class="form-control">
                
                      <option value="work">Work</option>
                      <option value="personal">Personal</option>
                      <option value="shopping">Shopping</option> 
        
                    </select>
                </div>	
                <div class="form-group">
				    <label>Start Date</label>
				</div>
					
                <div class="form-group">
                    <input type="date" name="sdate" id="sdate" class="form-control" required>
                </div>	
                <div class="form-group">
                    <label>priority</label>
                </div>
					
                <div class="form-group">
					
                    <select id="priority" name="priority" class="form-control">
                        <option value="">Select</option>
                        <option value="high">High</option>
                        <option value="medium">Medium</option>
                        <option value="low">Low</option> 
                    </select>
                </div>	
                <div class="form-group">
                                <label>Name</label>
				        </div>
					
                <div class="form-group">
				
                    <?php $assigns = $this->db->select('id,name')
                                            ->where('role','student')
                                            ->get('account')
                                            ->result(); ?>

                <select name="name" id="name" class="form-control">

                    <option value="">Select</option>
                    <?php foreach ($assigns as $assign): ?>
                    <option value="<?php echo $assign->name;?>"><?php echo $assign->name; ?></option>
                    <?php endforeach; ?>

                </select>
                </div>	    
                <div class="form-group">
                                <label>Assigned to</label>
				        </div>
					
                <div class="form-group">
				
                    <?php $assigns = $this->db->select('id,name,email')
                                            ->where('role','student')
                                            ->get('account')
                                            ->result(); ?>

                <select name="assignedto" id="assignedto" class="form-control">

                    <option value="">Select</option>
                    <?php foreach ($assigns as $assign): ?>
                    <option value="<?php echo $assign->email;?>"><?php echo $assign->name; ?></option>
                    <?php endforeach; ?>

                </select>
                </div>	
                <div class="form-group">
					<label>Due Date</label>
				</div>
					
                <div class="form-group">
					<input type="date" name="ddate" id="ddate" class="form-control" required>
				</div>	
                <div class="form-group">
					<label>Summary</label>
				</div>
                <div class="form-group">
                    <input type="text" name="summary" id="summary" class="form-control" >     
                </div>	
                 <div class="form-group">
					<label>Description/steps</label>
				</div>
					
                <div class="form-group">
					<input type="text" name="steps" id="steps" class="form-control" >
				</div>	
        <div class="form-group">
                    <label>Status</label>
                </div>
					
                <div class="form-group">
					
                    <select id="status" name="status" class="form-control">
                    <option value="assigned" class="blueText">Assigned</option>
                     <option value="ongoing">On Going</option>
                     <option value="done" class="greenText" >Done</option> 
                     <option value="redo" class="redText">Redo</option> 
                     <option value="enhance">Enhance</option> 
                    </select>
                         
                     </div>  
                     <div class="modal-footer">  
                          <input type="hidden" name="user_id" id="user_id" /> 
                          <input type="hidden" name="action" class="btn btn-success" value="Edit" />
                           
                          <input type="submit" name="action" id="action" class="btn btn-success" />  
                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                     </div>  
                </div>  
           </form>  
      </div>  
 </div>  


 
 <script type="text/javascript" language="javascript" >  
 $(document).ready(function(){  
      $('#add_button').click(function(){  
           $('#user_form')[0].reset();  
           $('.modal-title').text("Add User");  
           $('#action').val("Add");  
           $('#user_uploaded_image').html('');  
      })  
      var dataTable = $('#user_data').DataTable({  
           "processing":true,  
           "serverSide":true,  
           "order":[],  
           "ajax":{  
                url:"<?php echo base_url("index.php/Task/fetch_user"); ?>",  
                type:"POST"  
           },  
           "columnDefs":[  
                {  
                     "targets":[0, 3, 4],  
                     "orderable":false,  
                },  
           ],  
      });  
      $(document).on('submit', '#user_form', function(event){  
           event.preventDefault();  
           var project = $('#project').val();  
           var category = $('#category').val();  
           var sdate = $('#sdate').val();  
           var priority = $('#priority').val();  
           var name = $('#name').val();  
           var assignedto = $('#assignedto').val();  
           var ddate = $('#ddate').val();  
           var status = $('#status').val();  
                 
            
                $.ajax({  
                     url:"<?php echo base_url("index.php/Task/user_action");?>",  
                     method:'POST',  
                     data:new FormData(this),  
                     contentType:false,  
                     processData:false,  
                     success:function(data)  
                     {  
                          alert(data);  
                          $('#user_form')[0].reset();  
                          $('#userModal').modal('hide');  
                          dataTable.ajax.reload();  
                     }  
                });  
           
      });   
      $(document).on('click', '.update', function(){  
           var user_id = $(this).attr("id");  
           $.ajax({  
                url:"<?php echo base_url(); ?>index.php/Task/fetch_single_user",  
                method:"POST",  
                data:{user_id:user_id},  
                dataType:"json",  
                success:function(data)  
                {   
                     $('#userModal').modal('show');  
                     $('#project').val(data.project);  
                     $('#category').val(data.category);
                     $('#sdate').val(data.sdate);
                     $('#priority').val(data.priority);   
                     $('#name').val(data.name);  
                     $('#assignedto').val(data.assignedto);  
                     $('#ddate').val(data.ddate);  
                     $('#status').val(data.status);    
                     $('.modal-title').text("Edit User");  
                     $('#user_id').val(user_id);  
                      
                     $('#action').val("Edit");  
                }  
           })  
      });  
     });




     $(document).on("click", ".delete", function() {
    var $ele = $(this).parent().parent();
    $(this).attr('id');
    $.ajax({
        url: "<?php echo base_url("index.php/Task/deleterecords");?>",
        type: "POST",
        cache: false,
        data: {
            type: 2,
            user_id: $(this).attr("id")
        },
        success: function(dataResult) {
            alert(dataResult);
            let successHtml = '<div class="alert alert-success" role="alert"><b>Project Deleted Successfully</b></div>';
            $("#alert-div").html(successHtml);
            var dataResult = JSON.parse(dataResult);
            if(dataResult.statusCode == 200) {
                $ele.fadeOut().remove();
            }
        }
    });
});


</script>  
 

</body>  
 </html> 
   

