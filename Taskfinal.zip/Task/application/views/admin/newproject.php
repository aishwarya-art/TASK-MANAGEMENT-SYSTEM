<html>  
 <head>  
   <title>Project</title>  
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
      <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
      <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
      <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />  
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
      
      <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="icon" href="https://codingbirdsonline.com/wp-content/uploads/2019/12/cropped-coding-birds-favicon-2-1-192x192.png" type="image/x-icon"> 
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    
<style>
 @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');
*{ 
  margin: 0;  
  padding: 0;
  box-sizing: border-box;
  font-family: Arial;
}
.sidebar{
  position: fixed;
  height: 100%;
  width: 240px;
  background-color: #0e1a35;
  transition: all 0.5s ease;
}
.sidebar.active{
  width: 60px;
}
.sidebar .logo-details{
  height: 80px;
  display: flex;
  align-items: center;
}
.sidebar .logo-details i{
  font-size: 28px;
  font-weight: 500;
  color:black;
  min-width: 60px;
  text-align: center
}
.sidebar .logo-details .logo_name{
  color: #0a0a0a;
  font-size: 24px;
  font-weight: 500;
}
.sidebar .nav-links{
  margin-top: 10px;
}
.sidebar .nav-links li{
  position: relative;
  list-style: none;
  height: 50px;
}
.sidebar .nav-links li a{
  height: 100%;
  width: 100%;
  display: flex;
  align-items: center;
  text-decoration: none;
  transition: all 0.4s ease;
}
.sidebar .nav-links li a.active{

  background:#c0c0c0;
}
.sidebar .nav-links li a:hover{
    background-color: white;
  color: white !important;

}
.sidebar .nav-links li i{
  min-width: 60px;
  text-align: center;
  font-size: 18px;
  color: #0f0f0f;
  
}
.sidebar .nav-links li a .links_name{
  color: #0e0d0d;
  
  font-size: 15px;
  font-weight: 400;
  white-space: nowrap;
}
.sidebar .nav-links .log_out{
  position: absolute;
  bottom: 0;
  width: 100%;
}
.home-section{
  position: relative;
  background: #f5f5f5;
  min-height: 100vh;
  width: calc(100% - 240px);
  left: 240px;
  transition: all 0.5s ease;
}
.sidebar.active ~ .home-section{
  width: calc(100% - 60px);
  left: 60px;
}
.home-section nav{
  display: flex;
  justify-content: space-between;
  height: 80px;
  background: #fff;
  display: flex;
  align-items: center;
  position: fixed;
  width: calc(100% - 240px);
  left: 240px;
  z-index: 100;
  padding: 0 20px;
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
  transition: all 0.5s ease;
} 
.sidebar.active ~ .home-section nav{
  left: 60px;
  width: calc(100% - 60px);
}
.home-section nav .sidebar-button{
  display: flex;
  align-items: center;
  font-size: 24px;
  font-weight: 500;
}
nav .sidebar-button i{
  font-size: 35px;
  margin-right: 10px;
}
.home-section nav .search-box{
  position: relative;
  height: 50px;
  max-width: 550px;
  width: 100%;
  margin: 0 20px;
}
nav .search-box input{
  height: 100%;
  width: 100%;
  outline: none;
  background: #f5f6fa;
  border: 2px solid #EFEEF1;
  border-radius: 6px;
  font-size: 18px;
  padding: 0 15px;
}

.home-section nav .profile-details{
  display: flex;
  align-items: center;
  background:#0e1a35;
  border: 1px solid #0e1a35;
  border-radius: 6px;
  height: 50px;
  min-width: 190px;
  padding: 0 15px 0 2px;
}
nav .profile-details img{
  height: 40px;
  width: 40px;
  border-radius: 6px;
  object-fit: cover;
}
nav .profile-details .admin_name{
  font-size: 15px;
  font-weight: 500;
  color:White;
  margin: 0 10px;
  white-space: nowrap;
}
nav .profile-details i{
  font-size: 25px;
  color: black;
}
.home-section .home-content{
  position: relative;
  padding-top: 104px;
}

/* Responsive Media Query */
@media (max-width: 1240px) {
  .sidebar{
    width: 60px;
  }
  .sidebar.active{
    width: 220px;
  }
  .home-section{
    width: calc(100% - 60px);
    left: 60px;
  }
  .sidebar.active ~ .home-section{
    overflow: hidden;
    left: 220px;
  }
  .home-section nav{
    width: calc(100% - 60px);
    left: 60px;
  }
  .sidebar.active ~ .home-section nav{
    width: calc(100% - 220px);
    left: 220px;
  }
}

@media (max-width: 700px) {
  nav .sidebar-button .dashboard,
  nav .profile-details .admin_name,
  nav .profile-details i{
    display: none;
  }
  .home-section nav .profile-details{
    height: 50px;
    min-width: 40px;
  }
  
}
@media (max-width: 550px) {
 
  .sidebar.active ~ .home-section nav .profile-details{
    display: none;
  }
}
  @media (max-width: 400px) {
  .sidebar{
    width: 0;
  }
  .sidebar.active{
    width: 60px;
  }
  .home-section{
    width: 100%;
    left: 0;
  }
  .sidebar.active ~ .home-section{
    left: 60px;
    width: calc(100% - 60px);
  }
  .home-section nav{
    width: 100%;
    left: 0;
  }
  .sidebar.active ~ .home-section nav{
    left: 60px;
    width: calc(100% - 60px);
  }
}
 
</style>
<style>

a:focus,a:hover,a{
    outline:none;
    text-decoration: none;
}
li,ul{
    list-style: none;
    padding: 0;
    margin: 0;
}

.navi i {
    font-size: 20px;
}


.navi a {
    border-bottom: 1px solid #0d172e;
    border-top: 1px solid #0d172e;
    color: #ffffff;
    display: block;
    font-size: 17px;
    font-weight: 500;
    padding: 28px 20px;
    text-decoration: none;
}

.navi i {
    margin-right: 15px;
    color: #5584ff;
}

.navi .active a {
    background: #122143;
    border-left: 5px solid #5584ff;
    padding-left: 15px;
}

.navi a:hover {
    background: #122143 none repeat scroll 0 0;
    border-left: 5px solid #5584ff;
    display: block;
    padding-left: 15px;
}

</style>
       
</head>
<body>
 <!-- Sidebar Details -->
 <div>
  <div class="sidebar">
    <div class="logo-details">
   
      <i class=''></i>
      <span class="logo_name">
        <a href="<?php echo base_url('index.php/Dashboard/dashboard');?>" style="color:White;">FlairBrainz</a></span>
      </a>
    </div>
    <!-- Navigation Links -->
      <div class="navi">
          <ul>
              <li ><a href="<?php echo base_url('index.php/Dashboard/dashboard');?>"><i class="bx bx-home" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Home</span></a></li>
              <li class="active"><a href="<?php echo base_url('index.php/Ajax/index');?>"><i class='bx bx-list-ul'  aria-hidden="true"></i><span class="hidden-xs hidden-sm">Workflow</span></a></li>
              <li><a href="<?php echo base_url('index.php/Task/index');?>"><i class="bx bx-bar-chart" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Statistics</span></a></li>
              <li><a href="<?php echo base_url('index.php/Dashboard/calendar');?>"><i class="bx bx-calendar" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Calender</span></a></li>
              <li><a href="#" onclick="logout()"> <i class='bx bx-log-out'></i><span class="hidden-xs hidden-sm">Logout</span></a></li>
          </ul>
      </div>
  </div>

      <!-- Logout Confirmation Javascript -->
        <script>
            function logout() {
            var confirmed = confirm("<?php echo $this->lang->line('logoutconfirm'); ?>");

            if (confirmed) {
                
                window.location.href = "<?php echo base_url('index.php/Logout/index');?>";
            }
            }
        </script>

  <!-- Top Nav Content -->
  <section class="home-section">
    <nav>
        <div class="sidebar-button">
          <i class='bx bx-menu sidebarBtn'></i>
          <span class="dashboard">Dashboard</span>
        </div>

        <div class="profile-details">
          <a  href="" data-toggle="modal" data-target="#myModal"  aria-haspopup="true" aria-expanded="false"><span class="admin_name"><b><?php echo $name?></b></span></a>
          <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBhMIBwgWFQkXGBkbGBgYGR4WFRseHxgXHxgeGxUeHSgiHR4tHx4dITEhJS0rLi4uHR8zODMtNygtLi0BCgoKBQUFDgUFDisZExkrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrK//AABEIAMgA+gMBIgACEQEDEQH/xAAcAAEAAgIDAQAAAAAAAAAAAAAABwgFBgIDBAH/xABBEAACAQIDBAUIBwUJAAAAAAAAAQIDBQQGEQcSITEiQVFhkRMyYnGBobHRCBcjQlNUkxQkUsHhJTNDgoOSotLw/8QAFAEBAAAAAAAAAAAAAAAAAAAAAP/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhEDEQA/AJxAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANBzvtSsuVm8LTfl7iv8OD4Rfpz6vVzNf2x7Rqlp1y/Yqn7/JfaTXOCf3Y+k/cYvZvsiWJpxu+botuXSjRber1471R8+PZ4gYKttF2g5qrOnYaEo09eVCnvaeuo9f5H1Zf2uVl5V1cTr310n4b5YbB4PD4HDrD4OhGFFcoxSjFexHoArdPMW1LKn2lwjXdFfiwVWH+9cvE3TJ+2u33GpHC5hoKhXeiVSLbpN9/XH3olqUYzjuyXR8URvn3ZNab/Sli7RTjQuXF8OFOb7JJcvWgJGpVadamqlKacGtU09Vp2pnaV32dZ1uOSb28t5mUlgd7de9zpN8mvRf9SwsJxnHei9YvwA5gAAAAAAAAAAAAAAAAAAAAAAAAAAAABhc4XuGXct17rU504txXbJ8IrxaM0RL9IvHzoZWoYOL4VKur9UI6/FoDUdjWW55qzLVzFeFv0qct7pcVOrLite5c/AsQaNsZt0bfs+wziunUUqj795vT3JG8gAAAAAET7d8oU7lZHfsJT/faPn6c5U+vXvjz9Wp7NhmZpXvK7wGKnrisO1HvcH5j9nFewkTG4anjcHPC1lrTnGUX6mtGV82GV52zaJWtbfRlCpB+unLVfBgWLAAAAAAAAAAAAAAAAAAAAAAAAAAAAACGfpJUZStWDrJdFVJp+txWnwJmNE2zWSV6yLVVGOtelpViuvSPnf8AFsDI7L68a+QMFOL4eSjH2x1T+BtREH0eswwxVkqWKrP7elJyiu2EuenqfxJfAAAAAAPjaS1fIrlso/fNsNTE0/7vXES9jbS+KJm2j5gp5bylXxrl9s4uFNdbnJaLw5+wjX6Odmm54m+Vo9HRUoPteu9N/ACcgAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ThGpBxmtYtNPs0ZzAFas32i47L87xu9pi/wBhlJypv7uj8+nL/wBy0J0ydmu25stixlvqdNab8G+nB9jX8z3X6y4DMFslb7pQUsPLxT6mn1NEB3/Ieatn9yd1y3XnPCLlOnxml2VKfWvFAWPBBWX9u9SnFUcxWvemuc6T0ftpv5m109tuUJw1lKspdnk9X7mBJR5LlcMJbMHLGY+vGGHitZSlwSRE962822lBxs1rqTqdTqNQj4LVmkbmedq2OXlE1gU+vWGHh/2fiwOeb77ctqebadrs9NrBRbVNPlp96pPs4e4sBlix4XLljpWrBroQSTfXJ9cn62YrIeRrbk7A+Twy3sZJLylV+dJ9i7I9xtgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABrOc862jJ+C8tcautdroUo8Zy+S72Qtjdoees6Yt4XLlCdOl/DRWskvSqvl7gLHNpc2fHOL4byK5w2XbQ7gvLYvFaTf4lduXu1Pv1PZ6/PU/wBaXyAmi85Jyve5OdxtNKVR/eXRn4x0NdnsZyXKW8qFRLs8q9COfqez1+ep/rS+Q+p7PX56n+tL5AS1a9muTrXNVKFohKouTqN1PdJ6G20o0aNNU6SUYLqWiS9hXj6ns9fnqf60vkPqez1+ep/rS+QFi1KL5M5Fcnskz5RW/Sxkd7uryTOiV22l5DmpY91XhV+J9tSf+fjp4oCygI62f7VLbmqSwWMiqFz/AIW+hN+g+3uZIoAAAAAAAAAAAAAAAAAAAAAAAAAwecMw4fK9gqXTE8d1aRj1yk/NijOECfSIu9XE3jDWKg+jGO/JdspvSPuXvAweUMt3TajmWpdr1Vl+xJ/aS7eynDs4eBYez2jAWTAxwVrw0adBdUVp7W+t97PBkmw0ct5ZoW2nHpRinN9s3xk37TPgAAAAAAAADqrUqdek6VaClBrimtU13o7QBA21jZpG003mLLFNxpRe9Upx+56cOxdq6jc9j2d5Zqs7wlwn/adHTefXOPVP19T/AKkhVqVOvSdKrDWDTTT4pp80VutUJZA2y/skHphXV3P9Op5vhqvACyoAAAAAAAAAAAAAAAAAAAAAAABBefMp3u6bXKWLpW+csC5UHv6awUYab2r6uTJ0AAAAAAAAAAAAAAAIN2t5TvVx2g4fH2u3znRlGkt6K1inGXHefVw0JyAHGGu50uZyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//Z" alt="user" class="rounded-circle" width="41" height="41">
        </div>
    </nav>

    <!-- Home Content -->
    <div class="home-content">
                
          <!-- Alert message for error an success messages -->
          <div id="alert-div">
             
              <?php if($this->session->flashdata('error')){?>
                    <p style="color:red"><?php  echo $this->session->flashdata('error');?></p>	
                    <?php } ?> 
                    <p>

                    <?php if($this->session->flashdata('msg')){?>
                    <p style="color:green"><?php  echo $this->session->flashdata('msg');?></p>	
                    <?php } ?>
            </div>
                   
                    
              
           <!-- Table to display projects-->
           <div class="table-responsive" style="margin-left:30px; margin-right:20px;">  
           
                <button><a class="btn btn-secondary" href="<?php echo base_url('index.php/Ajax/add') ?>">Create New</a></button>
                <br/><br/>  
                <table id="user_data" class="table table-bordered table-striped">  
                     <thead>  
                          <tr>  
                               <th width="10%">Project ID</th>  
                               <th width="15%">Project Title</th>  
                               <th width="10%">Phase</th>   
                               <th width="10%">Type</th> 
                               <th width="10%">Status</th>
                               <th width="10%">Description</th> 
                               <th width="5%">Edit</th> 
                               <th width="5%">Delete</th>

                          </tr>  
                     </thead>  
                </table>  
           </div>  
      </div>   
           
<!-- UPDATE PROJECT MODAL FORM JAVASCRIPT -->
 <div id="userModal" class="modal fade">  
      <div class="modal-dialog">  
           <form method="post" id="user_form">  
                <div class="modal-content">  
                     <div class="modal-header">  
                          <button type="button" class="close" data-dismiss="modal">&times;</button>  
                          <h4 class="modal-title">Edit Project</h4>  
                     </div>  
                     <div class="modal-body">  
                              
                      <div class="form-group">
                        <label>Title</label>
                      </div>
                      <div class="form-group">
                        <input type="text" name="title" id="title" class="form-control" required>
                      </div>
                
                      <div class="form-group">
                          <label>Phase</label>
                      </div>
                      <div class="form-group">
                          <select name="phase" id="phase" class="form-control">        
                              <option value="">Select</option>
                              <option value="phase1">Phase I</option>
                              <option value="phase2"> Phase II</option>
                          </select>
                      </div>	
                  
                  
                          
                      <div class="form-group">
                          <label>Project Type</label>
                      </div>	

                      <div class="form-group">		
                            <select id="priority" name="priority" class="form-control">
                                <option value="">Select</option>
                                <option value="service">Service</option>
                                <option value="product"> Product</option>
                            </select>
                      </div>	
                              
                    <div class="form-group">
                        <label>Status</label>
                    </div>				
                    <div class="form-group">				
                        <select id="status" name="status" class="form-control">
                            <option value="">Select</option>
                            <option value="development">Development</option>
                                <option value="design">Design</option>
                                <option value="implementation">Implementation</option>

                                <option value="maintenance">Maintenace</option>
                                <option value="testing">Testing</option>
                                <option value="requirements">Requirements</option>
                        </select>
                      </div>	
                
                    <div class="form-group">
                        <label>Details</label>
                    </div>
                    <div class="form-group">
                        <input type="text" name="details" id="details" class="form-control" required>
                    </div>	
				
                     </div>  
                     <div class="modal-footer">  
                          <input type="hidden" name="user_id" id="user_id" /> 
                          <input type="hidden" name="action" class="btn btn-success" value="Edit" />
                           
                          <input type="submit" name="action" id="action" class="btn btn-success" />  
                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                     </div>  
                </div>  
           </form>  
      </div>  
 </div>  
 

 <!-- AJAX FUNCTIONS EDIT PROJECT AND DELETE PROJECT -->
 

 <script type="text/javascript" language="javascript" >  
 $(document).ready(function(){  
      $('#add_button').click(function(){  
           $('#user_form')[0].reset();  
           $('.modal-title').text("Add User");  
           $('#action').val("Add");  
           $('#user_uploaded_image').html('');  
      })  
      var dataTable = $('#user_data').DataTable({  
           "processing":true,  
           "serverSide":true,  
           "order":[],  
           "ajax":{  
                url:"<?php echo base_url("index.php/Ajax/fetch_user"); ?>",  
                type:"POST"  
           },  
           "columnDefs":[  
                {  
                     "targets":[0, 3, 4],  
                     "orderable":false,  
                },  
           ],  
      });  
      $(document).on('submit', '#user_form', function(event){  
           event.preventDefault();  
           var title = $('#title').val();  
           var phase = $('#phase').val();  
           var priority = $('#priority').val();   
           var status = $('#status').val();  
           var details = $('#details').val();  
          
                 
            
                $.ajax({  
                     url:"<?php echo base_url("index.php/Ajax/user_action");?>",  
                     method:'POST',  
                     data:new FormData(this),  
                     contentType:false,  
                     processData:false,  
                     success:function(data)  
                     {  
                          alert(data);  
                          $('#user_form')[0].reset();  
                          $('#userModal').modal('hide');  
                          dataTable.ajax.reload();  
                     }  
                });  
           
      });   
      $(document).on('click', '.update', function(){  
           var user_id = $(this).attr("id");  
           $.ajax({  
                url:"<?php echo base_url(); ?>index.php/Ajax/fetch_single_user",  
                method:"POST",  
                data:{user_id:user_id},  
                dataType:"json",  
                success:function(data)  
                {   
                     $('#userModal').modal('show');  
                     $('#title').val(data.title);  
                     $('#phase').val(data.phase);
                 
                     $('#priority').val(data.priority);   
                     $('#status').val(data.status);  
                     $('#details').val(data.details);  
                        
                     $('.modal-title').text("Edit User");  
                     $('#user_id').val(user_id);  
                      
                     $('#action').val("Edit");  
                }  
           })  
      });  
     });




     $(document).on("click", ".delete", function() {
    var $ele = $(this).parent().parent();
    $(this).attr('id');
    $.ajax({
        url: "<?php echo base_url("index.php/Ajax/deleterecords");?>",
        type: "POST",
        cache: false,
        data: {
            type: 2,
            user_id: $(this).attr("id")
        },
        success: function(dataResult) {
            alert(dataResult);
            let successHtml = '<div class="alert alert-success" role="alert"><b>Project Deleted Successfully</b></div>';
            $("#alert-div").html(successHtml);
            var dataResult = JSON.parse(dataResult);
            if(dataResult.statusCode == 200) {
                $ele.fadeOut().remove();
            }
        }
    });
});

</script>  
 
        <!-- SIDE BAR SLIDING JAVASCRIPT FUNCTION -->
        <script>
            let sidebar = document.querySelector(".sidebar");
            let sidebarBtn = document.querySelector(".sidebarBtn");
            sidebarBtn.onclick = function() 
            {
              sidebar.classList.toggle("active");
              if(sidebar.classList.contains("active"))
              {
                sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
              }
              else
              sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
            }
        </script>


<!-- Confirm Password modal -->

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
          <h5 class="modal-title" id="myModalLabel">Confirm Password</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            
          </div>
          <div class="modal-body">         
              <form id="resetPassword" name="resetPassword" method="post" action="<?php echo base_url();?>index.php/Login/ConfirmPassword" onsubmit ='return validate()'>
              <table class="table table-bordered table-hover table-striped">                                      
                  <tbody>
                  <tr>
                  <label class="control-label col-md-12 text-dark">Password <span style="color: red">*</span></label>
                  <td>
                  <input type="password" name="password" id="myInput" style="width:250px" required>
                  <input type="checkbox" onclick="myFunction()">Show 
                  </td>
                  <td>
                  <input type = "submit" value="submit" class="button"></td>
                  </tr> 
                  </tbody>              
              </table>
              </form> 

            <div id="fade" class="black_overlay"></div>       
            </div>  
          <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
          </div>
        </div>
        </div>
      </div>
    </div>

</div>

      <!-- Show password javascript -->
        <script>
            function myFunction()
             {
                  var x = document.getElementById("myInput");
                  if (x.type === "password") {
                    x.type = "text";
                  } else {
                    x.type = "password";
                  }
                
              } 
          </script>


 

</div>
</body>
</html>
 


