

<html>   
 <head>  
   <title>Assign Task</title>  
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
      <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
      <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
      <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />  
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
      
      <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="https://codingbirdsonline.com/wp-content/uploads/2019/12/cropped-coding-birds-favicon-2-1-192x192.png" type="image/x-icon">
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
   
   
   </head>
<body>
  <?php
 ?>
 <div style="margin-top:-0px; margin-left:0px;">
  <div class="sidebar">
  <!-- <a href="<?php echo base_url('index.php/Dashboard/dashboard');?>"> -->
    <div class="logo-details">
   
      <i class=''></i>
      <span class="logo_name"><a href="<?php echo base_url('index.php/User/index');?>" style="color:White;">FlairBrainz</a></span>
    </a>
    </div>
      <!-- <ul class="nav-links">
      <li>
          <a href="<?php echo base_url('index.php/Dashboard/dashboard');?>" >
            <i class='bx bx-grid-alt' ></i>
            <span class="links_name">Dashboard</span>
          </a>
        </li>
        <li>
          <a href="<?php echo base_url('index.php/Ajax/index');?>">
            <i class='bx bx-box' ></i>
            <span class="links_name">Projects</span>
          </a>
        </li>
          <li>
          <a href="<?php echo base_url('index.php/Assign/ajaxmain');?>"class="active">
            <i class='bx bx-list-ul' ></i>
            <span class="links_name"> Tasks</span>
          </a>
        </li>
        <li>
          <a href="<?php echo base_url('index.php/Dashboard/calendar');?>">
            <i class='bx bx-coin-stack' ></i>
            <span class="links_name">Calendar</span>
          </a>
      </li> 
         
        </li><li class="log_out">
          <a href="<?php echo base_url('index.php/Logout/index');?>">
            <i class='bx bx-log-out'></i>
            <span class="links_name">Logout</span>
          </a>
        </li>   
      </ul> -->
      <div class="navi">
                    <ul>
                        <li ><a href="<?php echo base_url('index.php/Dashboard/dashboard');?>"><i class="bx bx-home" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Home</span></a></li>
                        <li ><a href="<?php echo base_url('index.php/Ajax/index');?>"><i class='bx bx-list-ul'  aria-hidden="true"></i><span class="hidden-xs hidden-sm">Workflow</span></a></li>
                        <li class="active"><a href="<?php echo base_url('index.php/Assign/ajaxmain');?>"><i class="bx bx-bar-chart" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Statistics</span></a></li>
                        <li><a href="<?php echo base_url('index.php/Dashboard/calendar');?>"><i class="bx bx-calendar" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Calender</span></a></li>
                        <li><a href="#" onclick="logout()"> <i class='bx bx-log-out'></i><span class="hidden-xs hidden-sm">Logout</span></a></li>
                    </ul>
                </div>
  </div>
  <section class="home-section" style="margin-left:0px;">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Dashboard</span>
      </div>

      <div class="profile-details">
      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQTHTAJPlLEQwOQG_g-WNP0WayMmnpM-Nq9ZA&usqp=CAU" alt="user" class="rounded-circle" width="31" height="31">
        <a  href="" data-toggle="modal" data-target="#myModal"  aria-haspopup="true" aria-expanded="false"><span class="admin_name"><b><?php echo $name?></b></span></a>
        <i class='bx bx-chevron-down' ></i>
      </div>
    </nav>
    <div class="home-content">
                <div class="welcome-text"style=" 
                display:flex;
                justify-content:center; margin:0px;" >
                <div class="card-body">
              <div id="alert-div">
             
            
               </div>
                     <?php if($this->session->flashdata('error')){?>
                    <p style="color:red"><?php  echo $this->session->flashdata('error');?></p>	
                    <?php } ?>
                    <p>

                    <?php if($this->session->flashdata('msg')){?>
                    <p style="color:green"><?php  echo $this->session->flashdata('msg');?></p>	
                    <?php } ?>
                   
                </p>  
     
                <script>
                        function logout() {
                        var confirmed = confirm("<?php echo $this->lang->line('logoutconfirm'); ?>");

                        if (confirmed) {
                            
                            window.location.href = "<?php echo base_url('index.php/Logout/index');?>";
                        }
                        }
                    </script>
                <script>
   let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function() {
  sidebar.classList.toggle("active");
  if(sidebar.classList.contains("active")){
  sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
}else
  sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
}
 </script>

<div class="row">

    <div class="col-lg-12 margin-tb">

        <div class="pull-left">
        <br>
            <h4>Enter Task Details.</h4>

        </div>

        <div class="pull-right">
        <br>
            <a class="btn btn-secondary" href="<?php echo base_url('index.php/Task/index');?>"> Back</a>

        </div>

    </div>

</div>
  
<?php echo @$error; ?> 
   

 <?php echo form_open_multipart('index.php/Task/add'); ?>

    <div class="row">
 
        <div class="col-xs-12 col-sm-12 col-md-12">

            <div class="form-group">

                <strong>Project:</strong>

                <?php $projects = $this->db->select('id,title')->get('project')->result(); ?>

                <select name="project" id="project" class="form-control">

                    <option value="">Select</option>
                    <?php foreach ($projects as $project): ?>
                    <option value="<?php echo $project->title; ?>"><?php echo $project->title; ?></option>
                    <?php endforeach; ?>

                </select>

            </div>

        </div>


            <div class="col-xs-12 col-sm-12 col-md-12">

                <div class="form-group">

                <strong> Category :</strong><br>
               

                <select name="category" id="category" class="form-control">
                
                <option value="work">Work</option>
                <option value="personal">Personal</option>
                <option value="shopping">Shopping</option> 
  
              </select>
       

             
            </div>

        </div>
        

        <div class="col-xs-12 col-sm-12 col-md-12">

            <div class="form-group">

                <strong>Start Date:</strong>

                <input type="date" name="sdate" id="sdate" class="form-control" required>
                <!-- <input type="text" class="form-control" id="sdate" name="sdate" disabled>  
                <script>document.getElementById("sdate").value = new Date().toLocaleDateString();  -->
               

            </div>

        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">

            <div class="form-group">

                 <strong>Priority:</strong>

                 <select id="priority" name="priority" class="form-control">
                        <option value="">Select</option>
                        <option value="high">High</option>
                        <option value="medium">Medium</option>
                        <option value="low">Low</option> 
                    </select>

            </div>

        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">

            <div class="form-group">

                <strong>Name:</strong>

                <?php $assigns = $this->db->select('id,name')
                                            ->where('role','student')
                                            ->get('account')
                                            ->result(); ?>

                <select name="name" id="name" class="form-control">

                    <option value="">Select</option>
                    <?php foreach ($assigns as $assign): ?>
                    <option value="<?php echo $assign->name;?>"><?php echo $assign->name; ?></option>
                    <?php endforeach; ?>

                </select>
            </div>

        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">

<div class="form-group">

    <strong>Assigned to:</strong>

    <?php $assigns = $this->db->select('id,name,email')
                                            ->where('role','student')
                                            ->get('account')
                                            ->result(); ?>

                <select name="assignedto" id="assignedto" class="form-control">

                    <option value="">Select</option>
                    <?php foreach ($assigns as $assign): ?>
                    <option value="<?php echo $assign->email;?>"><?php echo $assign->name; ?></option>
                    <?php endforeach; ?>

                </select>

</div>

</div>


<div class="col-xs-12 col-sm-12 col-md-12">

<div class="form-group">

    <strong>due Date:</strong>

    <input type="date" name="ddate" id="ddate" class="form-control" required>
   
   

</div>

</div>

<div class="col-xs-12 col-sm-12 col-md-12">

<div class="form-group">

    <strong>Status:</strong>

    <div class="form-group">
					
                    <select id="status" name="status" class="form-control">
                    <option value="assigned" class="blueText">Assigned</option>
                     <option value="ongoing">On Going</option>
                     <option value="done" class="greenText" >Done</option> 
                     <option value="redo" class="redText">Redo</option> 
                     <option value="enhance">Enhance</option> 
                    </select>
                         
   

</div>

</div>

       

        <div class="col-xs-12 col-sm-12 col-md-12 text-center">

        <input class="btn btn-secondary" type="submit" value="Upload" >

        </div>
        <?php echo form_close(); ?>

    </div>