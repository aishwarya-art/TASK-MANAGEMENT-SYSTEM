
<html>  
 <head>  
   <title>Create Project</title>  
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
      <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
      <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
      <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />  
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
      <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="icon" href="https://codingbirdsonline.com/wp-content/uploads/2019/12/cropped-coding-birds-favicon-2-1-192x192.png" type="image/x-icon">
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<style>
 @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');
*{ 
  margin: 0;  
  padding: 0;
  box-sizing: border-box;
  font-family: Arial;
}
.sidebar{
  position: fixed;
  height: 100%;
  width: 240px;
  background-color: #0e1a35;
  transition: all 0.5s ease;
}
.sidebar.active{
  width: 60px;
}
.sidebar .logo-details{
  height: 80px;
  display: flex;
  align-items: center;
}
.sidebar .logo-details i{
  font-size: 28px;
  font-weight: 500;
  color:black;
  min-width: 60px;
  text-align: center
}
.sidebar .logo-details .logo_name{
  color: #0a0a0a;
  font-size: 24px;
  font-weight: 500;
}
.sidebar .nav-links{
  margin-top: 10px;
}
.sidebar .nav-links li{
  position: relative;
  list-style: none;
  height: 50px;
}
.sidebar .nav-links li a{
  height: 100%;
  width: 100%;
  display: flex;
  align-items: center;
  text-decoration: none;
  transition: all 0.4s ease;
}
.sidebar .nav-links li a.active{

  background:#c0c0c0;
}
.sidebar .nav-links li a:hover{
    background-color: white;
  color: white !important;

}
.sidebar .nav-links li i{
  min-width: 60px;
  text-align: center;
  font-size: 18px;
  color: #0f0f0f;
  
}
.sidebar .nav-links li a .links_name{
  color: #0e0d0d;
  
  font-size: 15px;
  font-weight: 400;
  white-space: nowrap;
}
.sidebar .nav-links .log_out{
  position: absolute;
  bottom: 0;
  width: 100%;
}
.home-section{
  position: relative;
  background: #f5f5f5;
  min-height: 100vh;
  width: calc(100% - 240px);
  left: 240px;
  transition: all 0.5s ease;
}
.sidebar.active ~ .home-section{
  width: calc(100% - 60px);
  left: 60px;
}
.home-section nav{
  display: flex;
  justify-content: space-between;
  height: 80px;
  background: #fff;
  display: flex;
  align-items: center;
  position: fixed;
  width: calc(100% - 240px);
  left: 240px;
  z-index: 100;
  padding: 0 20px;
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
  transition: all 0.5s ease;
} 
.sidebar.active ~ .home-section nav{
  left: 60px;
  width: calc(100% - 60px);
}
.home-section nav .sidebar-button{
  display: flex;
  align-items: center;
  font-size: 24px;
  font-weight: 500;
}
nav .sidebar-button i{
  font-size: 35px;
  margin-right: 10px;
}
.home-section nav .search-box{
  position: relative;
  height: 50px;
  max-width: 550px;
  width: 100%;
  margin: 0 20px;
}
nav .search-box input{
  height: 100%;
  width: 100%;
  outline: none;
  background: #f5f6fa;
  border: 2px solid #EFEEF1;
  border-radius: 6px;
  font-size: 18px;
  padding: 0 15px;
}

.home-section nav .profile-details{
  display: flex;
  align-items: center;
  background:#0e1a35;
  border: 1px solid #0e1a35;
  border-radius: 6px;
  height: 50px;
  min-width: 190px;
  padding: 0 15px 0 2px;
}
nav .profile-details img{
  height: 40px;
  width: 40px;
  border-radius: 6px;
  object-fit: cover;
}
nav .profile-details .admin_name{
  font-size: 15px;
  font-weight: 500;
  color:White;
  margin: 0 10px;
  white-space: nowrap;
}
nav .profile-details i{
  font-size: 25px;
  color: black;
}
.home-section .home-content{
  position: relative;
  padding-top: 104px;
}

/* Responsive Media Query */
@media (max-width: 1240px) {
  .sidebar{
    width: 60px;
  }
  .sidebar.active{
    width: 220px;
  }
  .home-section{
    width: calc(100% - 60px);
    left: 60px;
  }
  .sidebar.active ~ .home-section{
    overflow: hidden;
    left: 220px;
  }
  .home-section nav{
    width: calc(100% - 60px);
    left: 60px;
  }
  .sidebar.active ~ .home-section nav{
    width: calc(100% - 220px);
    left: 220px;
  }
}

@media (max-width: 700px) {
  nav .sidebar-button .dashboard,
  nav .profile-details .admin_name,
  nav .profile-details i{
    display: none;
  }
  .home-section nav .profile-details{
    height: 50px;
    min-width: 40px;
  }
  
}
@media (max-width: 550px) {
 
  .sidebar.active ~ .home-section nav .profile-details{
    display: none;
  }
}
  @media (max-width: 400px) {
  .sidebar{
    width: 0;
  }
  .sidebar.active{
    width: 60px;
  }
  .home-section{
    width: 100%;
    left: 0;
  }
  .sidebar.active ~ .home-section{
    left: 60px;
    width: calc(100% - 60px);
  }
  .home-section nav{
    width: 100%;
    left: 0;
  }
  .sidebar.active ~ .home-section nav{
    left: 60px;
    width: calc(100% - 60px);
  }
}
 
</style>
<style>

a:focus,a:hover,a{
    outline:none;
    text-decoration: none;
}
li,ul{
    list-style: none;
    padding: 0;
    margin: 0;
}

.navi i {
    font-size: 20px;
}


.navi a {
    border-bottom: 1px solid #0d172e;
    border-top: 1px solid #0d172e;
    color: #ffffff;
    display: block;
    font-size: 17px;
    font-weight: 500;
    padding: 28px 20px;
    text-decoration: none;
}

.navi i {
    margin-right: 15px;
    color: #5584ff;
}

.navi .active a {
    background: #122143;
    border-left: 5px solid #5584ff;
    padding-left: 15px;
}

.navi a:hover {
    background: #122143 none repeat scroll 0 0;
    border-left: 5px solid #5584ff;
    display: block;
    padding-left: 15px;
}

</style>     
</head>
<body>
 <!-- sidebar  -->
 <div>
  <div class="sidebar">
    <div class="logo-details">
      <span class="logo_name">
        <a href="<?php echo base_url('index.php/Dashboard/dashboard');?>" style="color:White;">FlairBrainz</a></span>
      </a>
    </div>
        <div class="navi">
            <ul>
                <li ><a href="<?php echo base_url('index.php/Dashboard/dashboard');?>"><i class="bx bx-home" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Home</span></a></li>
                <li class="active"><a href="<?php echo base_url('index.php/Ajax/index');?>"><i class='bx bx-list-ul'  aria-hidden="true"></i><span class="hidden-xs hidden-sm">Workflow</span></a></li>
                <li><a href="<?php echo base_url('index.php/Assign/ajaxmain');?>"><i class="bx bx-bar-chart" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Statistics</span></a></li>
                <li><a href="<?php echo base_url('index.php/Dashboard/calendar');?>"><i class="bx bx-calendar" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Calender</span></a></li>
                <li><a href="#" onclick="logout()"> <i class='bx bx-log-out'></i><span class="hidden-xs hidden-sm">Logout</span></a></li>
            </ul>
        </div>
      </div>

      <!-- LOGOUT CONFIRMATION JAVASCRIPT -->
      <script>
        function logout() {
          var confirmed = confirm("<?php echo $this->lang->line('logoutconfirm'); ?>");

          if (confirmed) {
              
              window.location.href = "<?php echo base_url('index.php/Logout/index');?>";
          }
        }
      </script>

<!-- TOP NAV BAR WITH PROFILE  -->
  <section class="home-section" style="margin-left:-10px;">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard">Dashboard</span>
      </div>

      <div class="profile-details">
      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQTHTAJPlLEQwOQG_g-WNP0WayMmnpM-Nq9ZA&usqp=CAU" alt="user" class="rounded-circle" width="31" height="31">
        <a  href="" data-toggle="modal" data-target="#myModal"  aria-haspopup="true" aria-expanded="false"><span class="admin_name"><b><?php echo $name?></b></span></a>
        <i class='bx bx-chevron-down' ></i>
      </div>
    </nav>
    <!-- home content  -->
    <div class="home-content">
        <div id="alert-div">
        
            <?php if($this->session->flashdata('error')){?>
            <p style="color:red"><?php  echo $this->session->flashdata('error');?></p>	
            <?php } ?>
            <p>

            <?php if($this->session->flashdata('msg')){?>
            <p style="color:green"><?php  echo $this->session->flashdata('msg');?></p>	
            <?php } ?>

          </div>
               
        <!-- SIDEBAR SLIDE JAVASCRIPT FUNCTION -->
        <script>
          let sidebar = document.querySelector(".sidebar");
        let sidebarBtn = document.querySelector(".sidebarBtn");
        sidebarBtn.onclick = function() {
          sidebar.classList.toggle("active");
          if(sidebar.classList.contains("active")){
          sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
        }else
          sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
        }
        </script>



<div class="row">

    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
        <br>
            <h4>Enter Project Details.</h4>
        </div>

        <div class="pull-right">
        <br>
            <a class="btn btn-secondary" href="<?php echo base_url('index.php/Ajax/index');?>"> Back</a>

        </div>
    </div>

</div>
        
      <?php echo @$error; ?> 
   

<!-- form open for add new project details -->
 <?php echo form_open_multipart('index.php/Ajax/add'); ?>

    <div class="row">
 
        <div class="col-xs-12 col-sm-12 col-md-12">

            <div class="form-group">

                <strong>Title:</strong>

                <input type="text" name="title" id="title" class="form-control" required>

            </div>

        </div>

            <div class="col-xs-12 col-sm-12 col-md-12">

                <div class="form-group">

                <strong> Phase :</strong><br>
               
                <select name="phase" id="phase" class="form-control">        
                    <option value="">Select</option>
                    <option value="phase1">Phase I</option>
                    <option value="phase2"> Phase II</option>
                </select>
  
              </select>
       
            </div>

        </div>
        
        <div class="col-xs-12 col-sm-12 col-md-12">

            <div class="form-group">

                <strong>Project Type:</strong>

                <select id="priority" name="priority" class="form-control">
                      <option value="">Select</option>
                      <option value="service">Service</option>
                      <option value="product"> Product</option>
                  </select>
            </div>

        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">

            <div class="form-group">

                 <strong>Status:</strong>

                 <select id="status" name="status" class="form-control">
                  <option value="">Select</option>
                  <option value="development">Development</option>
                      <option value="design">Design</option>
                      <option value="implementation">Implementation</option>

                      <option value="maintenance">Maintenace</option>
                      <option value="testing">Testing</option>
                      <option value="requirements">Requirements</option>
              </select>

            </div>

        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">

            <div class="form-group">

                <strong>Details:</strong>

                <input type="text" name="details" id="details" class="form-control" required>
            </div>

        </div>

        <div class="col-xs-12 col-sm-12 col-md-12 text-center">

        <input class="btn btn-secondary" type="submit" value="Upload" >

        </div>
        <?php echo form_close(); ?>

    </div>
