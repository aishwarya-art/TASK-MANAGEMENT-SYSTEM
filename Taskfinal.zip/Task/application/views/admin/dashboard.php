<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="https://codingbirdsonline.com/wp-content/uploads/2019/12/cropped-coding-birds-favicon-2-1-192x192.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="https://cdn.syncfusion.com/ej2/dist/ej2.min.js" type="text/javascript"></script>
    <style>

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');
*{
  margin: 0; 
  padding: 0;
  box-sizing: border-box;
  font-family: Arial;
}
.sidebar{
  position: fixed;
  height: 100%;
  width: 240px;
  background-color: #0e1a35;
 
}
.sidebar.active{
  width: 60px;
}
.sidebar .logo-details{
  height: 80px;
  display: flex;
  align-items: center;
}
.sidebar .logo-details i{
  font-size: 28px;
  font-weight: 500;
  color:black;
  min-width: 60px;
  text-align: center
}
.sidebar .logo-details .logo_name{
  color: #0a0a0a;
  font-size: 24px;
  font-weight: 500;
}
.sidebar .nav-links{
  margin-top: 10px;
}
.sidebar .nav-links li{
  position: relative;
  list-style: none;
  height: 50px;
}

.sidebar .nav-links li a:hover{
    background-color: white;
  color: white !important;
  
}
.sidebar .nav-links li i{
  min-width: 60px;
  text-align: center;
  font-size: 20px;
  color: #0f0f0f; 
}
.sidebar .nav-links li a .links_name{
  color: #0e0d0d;
  font-size: 15px;
  font-weight: 400;
  white-space: nowrap;
}
.sidebar .nav-links .log_out{
  position: absolute;
  bottom: 0;
  width: 100%;
}
.home-section{
  position: relative;
  background: #f5f5f5;
  min-height: 100vh;
  width: calc(100% - 240px);
  left: 240px;
  transition: all 0.5s ease;
  
}
.sidebar.active ~ .home-section{
  width: calc(100% - 60px);
  left: 60px;
}
.home-section nav{
  display: flex;
  justify-content: space-between;
  height: 80px;
  background: #fff;
  display: flex;
  align-items: center;
  position: fixed;
  width: calc(100% - 240px);
  left: 240px;
  z-index: 100;
  padding: 0 20px;
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
  transition: all 0.5s ease;
 
}
.sidebar .logo-details{
  height: 80px;
  display: flex;
  align-items: center;
}
.sidebar .logo-details i{
  font-size: 28px;
  font-weight: 500;
  color:black;
  min-width: 60px;
  text-align: center
}
  .sidebar .logo-details .logo_name{
  color: #0a0a0a;
  font-size: 24px;
  font-weight: 500;
}
.sidebar.active ~ .home-section nav{
  left: 60px;
  width: calc(100% - 60px);
}
.home-section nav .sidebar-button{
  display: flex;
  align-items: center;
  font-size: 24px;
  font-weight: 500;
}
nav .sidebar-button i{
  font-size: 35px;
  margin-right: 10px;
}
.home-section nav .search-box{
  position: relative;
  height: 50px;
  max-width: 550px;
  width: 100%;
  margin: 0 20px;
}
nav .search-box input{
  height: 100%;
  width: 100%;
  outline: none;
  background: #f5f6fa;
  border: 2px solid #EFEEF1;
  border-radius: 6px;
  font-size: 18px;
  padding: 0 15px;
}

.home-section nav .profile-details{
  display: flex;
  align-items: center;
  background:#0e1a35;
  border: 1px solid #EFEEF1;
  border-radius: 6px;
  height: 50px;
  min-width: 190px;
  padding: 0 15px 0 2px;
}
nav .profile-details img{
  height: 40px;
  width: 40px;
  border-radius: 6px;
  object-fit: cover;
}
nav .profile-details .admin_name{
  font-size: 15px;
  font-weight: 500;
  color:White;
  margin: 0 10px;
  white-space: nowrap;
}
nav .profile-details i{
  font-size: 25px;
  color: black;
}
.home-section .home-content{
  position: relative;
  padding-top: 104px;
}

/* Responsive Media Query */
@media (max-width: 1240px) {
  .sidebar{
    width: 60px;
  }
  .sidebar.active{
    width: 220px;
  }
  .home-section{
    width: calc(100% - 60px);
    left: 60px;
  }
  .sidebar.active ~ .home-section{
   
    overflow: hidden;
    left: 220px;
  }
  .home-section nav{
    width: calc(100% - 60px);
    left: 60px;
  }
  .sidebar.active ~ .home-section nav{
    width: calc(100% - 220px);
    left: 220px;
  }
}

@media (max-width: 1000px) {
  .overview-boxes .box{
    width: calc(100% / 2 - 15px);
    margin-bottom: 15px;
  }
}
@media (max-width: 700px) {
  nav .sidebar-button .dashboard,
  nav .profile-details .admin_name,
  nav .profile-details i{
    display: none;
  }
  .home-section nav .profile-details{
    height: 50px;
    min-width: 40px;
  }
 
}
@media (max-width: 550px) {
 
  .sidebar.active ~ .home-section nav .profile-details{
    display: none;
  }
}
  @media (max-width: 400px) {
  .sidebar{
    width: 0;
  }
  .sidebar.active{
    width: 60px;
  }
  .home-section{
    width: 100%;
    left: 0;
  }
 
  .sidebar.active ~ .home-section{
    left: 60px;
    width: calc(100% - 60px);
  }
  .home-section nav{
    width: 100%;
    left: 0;
  } 
  .sidebar.active ~ .home-section nav{
    left: 60px;
    width: calc(100% - 60px);
  }
}
.card {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.5);
  transition: 0.3s;
 
  border-radius: 10px;
  
}

.card:hover {
  box-shadow: 0 20px 35px 0 rgba(0,0,0,0.5);
}
        </style>
          
  <style>

a:focus,a:hover,a{
    outline:none;
    text-decoration: none;
}
li,ul{
    list-style: none;
    padding: 0;
    margin: 0;
}

.navi i {
    font-size: 20px;
}


.navi a {
    border-bottom: 1px solid #0d172e;
    border-top: 1px solid #0d172e;
    color: #ffffff;
    display: block;
    font-size: 17px;
    font-weight: 500;
    padding: 28px 20px;
    text-decoration: none;
}

.navi i {
    margin-right: 15px;
    color: #5584ff;
}

.navi .active a {
    background: #122143;
    border-left: 5px solid #5584ff;
    padding-left: 15px;
}

.navi a:hover {
    background: #122143 none repeat scroll 0 0;
    border-left: 5px solid #5584ff;
    display: block;
    padding-left: 15px;
}

</style>

</head>
<body> 
  <!-- sidebar -->
 <div>
  <div class="sidebar">
    <div class="logo-details">
      <span class="logo_name" >
        <a href="<?php echo base_url('index.php/Dashboard/dashboard');?>"style="color:white;"><?php echo $this->lang->line('flairbrainz'); ?></a></span>
    </a>
    </div>
      <div class="navi">
                    <ul>
                        <li class="active"><a href="<?php echo base_url('index.php/Dashboard/dashboard');?>"><i class="bx bx-home" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Home</span></a></li>
                        <li><a href="<?php echo base_url('index.php/Ajax/index');?>"><i class='bx bx-list-ul'  aria-hidden="true"></i><span class="hidden-xs hidden-sm">Workflow</span></a></li>
                        <li><a href="<?php echo base_url('index.php/Task/index');?>"><i class="bx bx-bar-chart" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Statistics</span></a></li>
                        <li><a href="<?php echo base_url('index.php/Dashboard/calendar');?>"><i class="bx bx-calendar" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Calender</span></a></li>
                        <li><a href="#" onclick="logout()"> <i class='bx bx-log-out'></i><span class="hidden-xs hidden-sm">Logout</span></a></li>
                    </ul>
      </div>
  </div>
  <!-- top nav bar -->
  <section class="home-section" style="margin-left:0px;">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard"><?php echo $this->lang->line('dashboard'); ?></span>
      </div>

      <div>
          <select class="form-control" onchange="javascript:window.location.href='<?php echo base_url(); ?>index.php/LanguageSwitcher/switchLang/'+this.value;">        
                <option value="english" <?php if($this->session->userdata('site_lang') == 'english') echo 'selected="selected"'; ?>>English</option>
                
                <option value="kannada" <?php if($this->session->userdata('site_lang') == 'kannada') echo 'selected="selected"'; ?>>Kannada</option>     
                
          </select>
      </div>
      <!-- nav bar profile details -->
      <div class="profile-details">
      
      <li class="nav-item dropdown show">
						<a class="nav-link dropdown-toggle   waves-effect waves-dark pro-pic" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">

              <span class="admin_name"><b><?php echo $name?></b></span>
							<img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBhMIBwgWFQkXGBkbGBgYGR4WFRseHxgXHxgeGxUeHSgiHR4tHx4dITEhJS0rLi4uHR8zODMtNygtLi0BCgoKBQUFDgUFDisZExkrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrK//AABEIAMgA+gMBIgACEQEDEQH/xAAcAAEAAgIDAQAAAAAAAAAAAAAABwgFBgIDBAH/xABBEAACAQIDBAUIBwUJAAAAAAAAAQIDBQQGEQcSITEiQVFhkRMyYnGBobHRCBcjQlNUkxQkUsHhJTNDgoOSotLw/8QAFAEBAAAAAAAAAAAAAAAAAAAAAP/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhEDEQA/AJxAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANBzvtSsuVm8LTfl7iv8OD4Rfpz6vVzNf2x7Rqlp1y/Yqn7/JfaTXOCf3Y+k/cYvZvsiWJpxu+botuXSjRber1471R8+PZ4gYKttF2g5qrOnYaEo09eVCnvaeuo9f5H1Zf2uVl5V1cTr310n4b5YbB4PD4HDrD4OhGFFcoxSjFexHoArdPMW1LKn2lwjXdFfiwVWH+9cvE3TJ+2u33GpHC5hoKhXeiVSLbpN9/XH3olqUYzjuyXR8URvn3ZNab/Sli7RTjQuXF8OFOb7JJcvWgJGpVadamqlKacGtU09Vp2pnaV32dZ1uOSb28t5mUlgd7de9zpN8mvRf9SwsJxnHei9YvwA5gAAAAAAAAAAAAAAAAAAAAAAAAAAAABhc4XuGXct17rU504txXbJ8IrxaM0RL9IvHzoZWoYOL4VKur9UI6/FoDUdjWW55qzLVzFeFv0qct7pcVOrLite5c/AsQaNsZt0bfs+wziunUUqj795vT3JG8gAAAAAET7d8oU7lZHfsJT/faPn6c5U+vXvjz9Wp7NhmZpXvK7wGKnrisO1HvcH5j9nFewkTG4anjcHPC1lrTnGUX6mtGV82GV52zaJWtbfRlCpB+unLVfBgWLAAAAAAAAAAAAAAAAAAAAAAAAAAAAACGfpJUZStWDrJdFVJp+txWnwJmNE2zWSV6yLVVGOtelpViuvSPnf8AFsDI7L68a+QMFOL4eSjH2x1T+BtREH0eswwxVkqWKrP7elJyiu2EuenqfxJfAAAAAAPjaS1fIrlso/fNsNTE0/7vXES9jbS+KJm2j5gp5bylXxrl9s4uFNdbnJaLw5+wjX6Odmm54m+Vo9HRUoPteu9N/ACcgAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ThGpBxmtYtNPs0ZzAFas32i47L87xu9pi/wBhlJypv7uj8+nL/wBy0J0ydmu25stixlvqdNab8G+nB9jX8z3X6y4DMFslb7pQUsPLxT6mn1NEB3/Ieatn9yd1y3XnPCLlOnxml2VKfWvFAWPBBWX9u9SnFUcxWvemuc6T0ftpv5m109tuUJw1lKspdnk9X7mBJR5LlcMJbMHLGY+vGGHitZSlwSRE962822lBxs1rqTqdTqNQj4LVmkbmedq2OXlE1gU+vWGHh/2fiwOeb77ctqebadrs9NrBRbVNPlp96pPs4e4sBlix4XLljpWrBroQSTfXJ9cn62YrIeRrbk7A+Twy3sZJLylV+dJ9i7I9xtgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABrOc862jJ+C8tcautdroUo8Zy+S72Qtjdoees6Yt4XLlCdOl/DRWskvSqvl7gLHNpc2fHOL4byK5w2XbQ7gvLYvFaTf4lduXu1Pv1PZ6/PU/wBaXyAmi85Jyve5OdxtNKVR/eXRn4x0NdnsZyXKW8qFRLs8q9COfqez1+ep/rS+Q+p7PX56n+tL5AS1a9muTrXNVKFohKouTqN1PdJ6G20o0aNNU6SUYLqWiS9hXj6ns9fnqf60vkPqez1+ep/rS+QFi1KL5M5Fcnskz5RW/Sxkd7uryTOiV22l5DmpY91XhV+J9tSf+fjp4oCygI62f7VLbmqSwWMiqFz/AIW+hN+g+3uZIoAAAAAAAAAAAAAAAAAAAAAAAAAwecMw4fK9gqXTE8d1aRj1yk/NijOECfSIu9XE3jDWKg+jGO/JdspvSPuXvAweUMt3TajmWpdr1Vl+xJ/aS7eynDs4eBYez2jAWTAxwVrw0adBdUVp7W+t97PBkmw0ct5ZoW2nHpRinN9s3xk37TPgAAAAAAAADqrUqdek6VaClBrimtU13o7QBA21jZpG003mLLFNxpRe9Upx+56cOxdq6jc9j2d5Zqs7wlwn/adHTefXOPVP19T/AKkhVqVOvSdKrDWDTTT4pp80VutUJZA2y/skHphXV3P9Op5vhqvACyoAAAAAAAAAAAAAAAAAAAAAAABBefMp3u6bXKWLpW+csC5UHv6awUYab2r6uTJ0AAAAAAAAAAAAAAAIN2t5TvVx2g4fH2u3znRlGkt6K1inGXHefVw0JyAHGGu50uZyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//Z" alt="user" class="rounded-circle" width="41" height="41">
						</a>
						
						<div class="dropdown-menu dropdown-menu-right user-dd animated show">
							
							<a class="dropdown-item" ><a class="nav-link dropdown-toggle" href="" data-toggle="modal" data-target="#myModal"  aria-haspopup="true" aria-expanded="false"> <?php echo $this->lang->line('profile'); ?></a>
							<div class="dropdown-divider"></div>
							<a class="dropdown-item" href=""data-toggle="modal" data-target="#password" ><i class="ti-settings m-r-5 m-l-5"></i><?php echo $this->lang->line('changepassword'); ?></a>
							<div class="dropdown-divider"></div>
						  <a class="dropdown-item" href="#" onclick="logout()"><i class="fa fa-power-off m-r-5 m-l-5"></i> <?php echo $this->lang->line('logout'); ?></a>

                  <script>
                      function logout() {
                      var confirmed = confirm("<?php echo $this->lang->line('logoutconfirm'); ?>");

                      if (confirmed) {
                          
                          window.location.href = "<?php echo base_url('index.php/Logout/index');?>";
                      }
                      }
                  </script>

						</div>
					</li>
      </div>
    </nav>

    <!-- home content -->
    <div class="home-content">

      <div id="alert-div">
         <!-- display errors or success message -->
        <?php if($this->session->flashdata('error')){?>
        <p style="color:red"><?php  echo $this->session->flashdata('error');?></p>	
        <?php } ?>
        <p>

        <?php if($this->session->flashdata('msg')){?>
        <p style="color:green"><?php  echo $this->session->flashdata('msg');?></p>	
        <?php } ?> 
      </div> 
                <!-- cards count queries -->
                  <?php
                  
                  $this->db->select("*");
                  $this->db->from("project");
                  
                  $project = $this->db->count_all_results();
                  ?>
                   <?php
                  
                  $this->db->select("*");
                  $this->db->from("assign");
                  
                  $task = $this->db->count_all_results();
                  ?>
                  <?php
                  
                  $this->db->select("*");
                  $this->db->from("account");
                  $this->db->where('role','student');
                  $employee = $this->db->count_all_results();
                  ?>

        <!-- Cards display  -->
        <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
               
                    <p class="card-text" style="text-align:center;"> <i class='bx bx-grid-alt'></i> <b><?php echo $this->lang->line('projects'); ?> <?php echo $project; ?> </b></p>
                    
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
               
                    <p class="card-text"style="text-align:center;"><b><i class='bx bx-list-ul' ></i><?php echo $this->lang->line('tasks'); ?> <?php echo $task; ?></b> </p>
                    
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
               
                    <p class="card-text"style="text-align:center;"><b><i class='bx bx-user' ></i><?php echo $this->lang->line('users'); ?> <?php echo $employee; ?></b> </p>
                    
                </div>
            </div>
        </div>
        </div>
        
        <!-- Pie chart dispaly -->
        <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
        </p><div id="myPlot" style="width:50%;max-width:600px;"></div>
       
       <!-- Query for pie chart counts -->
        <?php
                  
                    $this->db->select("*");
                    $this->db->from("project");
                    $this->db->where('status','development');
                    $query = $this->db->count_all_results();
                    ?>
                     <?php

                      $this->db->select("*");
                      $this->db->from("project");
                      $this->db->where('status','design');
                      $design= $this->db->count_all_results();
                      ?>
                     <?php
                      $this->db->select("*");
                      $this->db->from("project");
                      $this->db->where('status','requirement');
                      $requirement = $this->db->count_all_results();
                    
                    ?> 
                    <?php
                      
                      $this->db->select("*");
                     $this->db->from("project");
                     $this->db->where('status','testing');
                    $testing= $this->db->count_all_results();
                    ?>
                     <?php
                     $this->db->select("*");
                     $this->db->from("project");
                     $this->db->where('status','implementation');
                      
                    $implementation= $this->db->count_all_results();
                    ?>
                     <?php
                      $this->db->select("*");
                      $this->db->from("project");
                      $this->db->where('status','maintenance');
                      
                    $maintenance= $this->db->count_all_results();
                    ?>

        <!-- Pie chart javascript dispaly-->
        <script>
        const xArray = ['<?php echo $this->lang->line('development'); ?>', "<?php echo $this->lang->line('design'); ?>", "<?php echo $this->lang->line('requirement'); ?>", "<?php echo $this->lang->line('testing'); ?>","<?php echo $this->lang->line('implementation'); ?>","<?php echo $this->lang->line('maintenance'); ?>"];
        const yArray = [<?php echo $query; ?>, <?php echo $design; ?>, <?php echo $design; ?>, <?php echo $testing; ?>, <?php echo $implementation; ?>,<?php echo $maintenance; ?>];

        const layout ={title: "<?php echo $this->lang->line('projectstatus'); ?>"};

        const data = [{labels:xArray, values:yArray, type:"pie"}];

        Plotly.newPlot("myPlot", data, layout);
        </script>

        </div>
      </div>  
    </div>
  </div>
  </section>
  </div>
</div>

          <!-- Sidebar sliding javascript -->
          <script>
            let sidebar = document.querySelector(".sidebar");
          let sidebarBtn = document.querySelector(".sidebarBtn");
          sidebarBtn.onclick = function() {
            sidebar.classList.toggle("active");
            if(sidebar.classList.contains("active")){
            sidebarBtn.classList.replace("bx-menu" ,"bx-menu-alt-right");
          }else
            sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
          }
          </script>


<!-- profile details modal form -->

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
          <h5 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('confirmpassword'); ?></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            
          </div>
          <div class="modal-body">         
              <form id="resetPassword" name="resetPassword" method="post" action="<?php echo base_url();?>index.php/Login/ConfirmPassword" onsubmit ='return validate()'>
             <table class="table table-bordered table-hover table-striped">                                      
                        <tbody>
                        <tr>
                        <label class="control-label col-md-12 text-dark"><?php echo $this->lang->line('password'); ?> <span style="color: red">*</span></label>
                        <td>
                    <input type="password" name="password" id="myInput" style="width:250px" required>
                    <input type="checkbox" onclick="myFunction()">
                    <!-- <?php echo $this->lang->line('show'); ?>  -->
                     </td>
                        <td><input type = "submit" value="<?php echo $this->lang->line('submit'); ?>" class="btn btn-primary"></td>
                        </tr>
                       
                        </tbody>               </table></form> 
                                         <div id="fade" class="black_overlay"></div>       
                                         
						
            </div>  
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('close'); ?></button>
        
          </div>
        </div>
        </div>
      </div>
    </div>

</div>
          <!-- Show password functinality  javascript-->
            <script>
                function myFunction() {
              var x = document.getElementById("myInput");
              if (x.type === "password") {
                x.type = "text";
              } else {
                x.type = "password";
              }
            } 
                </script>

 <!-- change password modal-->
 <div class="modal fade" id="password" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
          <h5 class="modal-title" id="myModalLabel"><?php echo $this->lang->line('changepassword'); ?></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            
          </div>
          <div class="modal-body">         
              <form id="resetPassword" name="resetPassword" method="post" action="<?php echo base_url();?>index.php/Login/change_pass" onsubmit ='return validate()'>
             <table class="table table-bordered table-hover table-striped">                                      
                        <tbody> 
                        <tr>
                        <div class="form-group">
                        <label ><?php echo $this->lang->line('oldpassword'); ?> <span style="color: red">*</span></label>
                        </div>
                        <div class="form-group">
                        <input type="password" name="old_pass" id="old_pass" style="width:250px" required>
                       &nbsp;  
                       </div>
                        <div class="form-group">
                        <label class=""><?php echo $this->lang->line('newpassword'); ?><span style="color: red">*</span></label>
                        </div>
                        <div class="form-group">
                        <input type="password" name="new_pass" id="new_pass" style="width:250px" required>
                        &nbsp; 
                        </div>
                        <div class="form-group">
                        <label class=""> <?php echo $this->lang->line('repeatpassword'); ?> <span style="color: red">*</span></label>
                        </div>
                        <div class="form-group">
                        <input type="password" name="confirm_pass" id="confirm_pass" style="width:250px" required>
                        &nbsp; 
                          </div>
                        <td><input type = "submit" value="<?php echo $this->lang->line('submit'); ?>" class="button"></td>
                        </tr>
                        </tbody>         
                    </table></form> 
                    <div id="fade" class="black_overlay"></div>       
                                         	
            </div>  
           <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $this->lang->line('close'); ?></button>
        
          </div>
        </div>
        </div>
      </div>
    </div>

</div>


</body>

</html>