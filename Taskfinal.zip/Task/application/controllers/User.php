<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    //IF USER NOT LOGGED IN,REDIRECTS TO LOGIN PAGE
    public function __construct() {
        parent::__construct(); 
        $this->load->database(); 
        $this->load->helper('url'); 
        $this->load->model('User_model');
        $this->load->library("form_validation");
        if(!$this->session->userdata('id'))
        redirect('index.php/Login');
    }    
     
    //LOAD THE USER DASHBOARD PAGE
    public function index() {
        
        $userfname=$this->session->userdata('name');
        $this->load->view('theme/include',['name'=>$userfname]);    
        $this->load->view('user/user',['name'=>$userfname]);    
    } 
 
    //CALL THE DISPLAY PROJECTS PAGE
    public function projects()
    {
        $this->load->model('Ajax_model');
        $userfname=$this->session->userdata('name');
        $this->load->view('theme/include',['name'=>$userfname]);
        $this->load->view('user/userdisplay',['name'=>$userfname]);
    }
    
    //FETCH THE PROJECT DETAILS FROM THE DATABASE 
    function fetch_user(){  
        $this->load->model("User_model");  
        $fetch_data = $this->User_model->make_datatables();  
        $data = array();  
        foreach($fetch_data as $row)  
        {   
             $sub_array = array();  
            
             $sub_array[] = $row->id;  
             $sub_array[] = $row->title;  
             $sub_array[] = $row->phase;  
             $sub_array[] = $row->priority;  
             $sub_array[] = $row->status;  
             $sub_array[] = $row->details;  
             $data[] = $sub_array;  
        }  
     
        $output = array(  
             "draw"                    =>     intval($_POST["draw"]),  
             "recordsTotal"          =>      $this->User_model->get_all_data(),  
             "recordsFiltered"     =>     $this->User_model->get_filtered_data(),  
             "data"                    =>     $data  
        );  
        header("Access-Control-Allow-Origin:*");
        echo json_encode($output);  
   }  

   //FUNCTION TO CALL THE TASK ASSIGNED PAGE VIEW
    public function view()
    {
        header('Access-Control-Allow-Origin: *');
        $userfname=$this->session->userdata('name');
        $this->load->view('theme/include',['name'=>$userfname]);
        $this->load->view('user/task',['name'=>$userfname]);
       
    } 

    //DISPLAY TASK ASSGNED PAGE WITH CONTENT
    public function tasks()

	{			
      
        $data=$this->User_model->tasks();
        foreach($data as $row)
        {
              echo "<tr>";
           
              echo "<td>".$row->project."</td>";
              echo "<td>".$row->category."</td>";
              echo "<td>".$row->sdate."</td>";
              echo "<td>".$row->priority."</td>";
              echo "<td>".$row->name."</td>";
              echo "<td>".$row->assignedto."</td>";
              echo "<td>".$row->ddate."</td>";
              echo "<td>".$row->status."</td>";
              echo "<td>
               
              <button type='button'  class='btn btn-outline-success btn-sm'data-toggle='modal' data-keyboard='false' data-backdrop='static' data-target='#update_country'
              data-id=".$row->id."
                
              data-project=".$row->project."
              data-category=".$row->category."
              data-sdate=".$row->sdate."
              data-priority=".$row->priority."
              data-name=".$row->name."
              data-assignedto=".$row->assignedto."
              data-ddate=".$row->ddate."
              data-summary=".$row->summary."
              data-steps=".$row->steps."
              data-status=".$row->status."
              >Update</button>
              
              </td>";
             
                        echo "</tr>";
                        
                echo "</tr>";
        }
	}

    //UPDATE TASKS BY USER -ONLY ENABLED STATUS UPDATE
    function updaterecords()
    {
         header('Access-Control-Allow-Origin: *');
        if ($this->input->post('type') == 3) {
    
            $id = $this->input->post('id');
            
            $status = $this->input->post('status');
    
            $this->User_model->updaterecords($id,$status);
    
            echo json_encode(array(
                "statusCode" => 200
            ));
        }
    }


    //CALL TO VIEW THE PROFILE DETAILS PAGE
    public function ajaxmain()
    {
        
        $userfname=$this->session->userdata('name');
        $this->load->view('theme/include',['name'=>$userfname]);
        $this->load->view('user/userprofile',['name'=>$userfname]);
    }
     
    //function to display the profile details after insertion
    public function viewajax()
    
    {			
        header('Access-Control-Allow-Origin: *');
        $data=$this->User_model->ajaxdisplay_records();
        ?>

        <div class="row">
        <?php foreach ($data as $row) { ?>
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">

                    <img src="<?php echo site_url('uploads/'.$row->image); ?>" alt="Avatar" style="width:75%; height:180px;" ><br>
                    <br><h5 class="card-title"><b><?php echo $row->name; ?></b></h5>
                    
                    <p class="card-text"><b> Official Email:</b><br> <?php echo $row->email; ?></p>
                    <p class="card-text"><b> Contact Number:</b><br> <?php echo $row->contact; ?></p>
                    
                </div>
            </div>
        </div>
        <?php } ?>
        
        <?php foreach ($data as $row) { ?>
        <div class="col-md-4 mb-4" style="">
            <div class="card">
                <div class="card-body">

                    <br><h6 class="card-title" style="color:#808080;"><b>Official Info</b></h6>
                    
                    <p class="card-text"><b> Department:</b><br> <?php echo $row->department; ?></p>
                    <p class="card-text"><b> Date Of Joining:</b><br> <?php echo $row->doj; ?></p>
                    <p class="card-text"><b> Reporting Manager:</b><br> <?php echo $row->reportingmanager; ?></p>
                    <p class="card-text"><b> Asset Id:</b><br> <?php echo $row->assetid; ?></p>
                    <p class="card-text"><b>Asset Type:</b><br> <?php echo $row->assettype; ?></p>
                    <p class="card-text"><b> Location:</b><br> <?php echo $row->location; ?></p>
            
                </div>
            </div>
        </div>
        <?php } ?>

        <?php foreach ($data as $row) { ?>
        <div class="col-md-4 mb-4" style="">
            <div class="card">
                <div class="card-body">

                    <br><h6 class="card-title" style="color:#808080;"><b>Personal Info</b></h6>
                    
                    <p class="card-text"><b> Gender:</b><br> <?php echo $row->gender; ?></p>
                    <p class="card-text"><b>Marital Status:</b><br> <?php echo $row->marritalstatus; ?></p>
                    <p class="card-text"><b> Nationality:</b><br> <?php echo $row->nationality; ?></p>
                    <p class="card-text"><b> Qualification:</b><br> <?php echo $row->qualification; ?></p>
                    <p class="card-text"><b> Work Experience:</b><br> <?php echo $row->experience; ?></p>
                    <p class="card-text"><b> Emergency Name:</b><br> <?php echo $row->emergencyname; ?></p>
                    <p class="card-text"><b> Emergency Contact:</b><br> <?php echo $row->emergencycontact; ?></p>
                    <p class="card-text"><b> Relationship:</b><br> <?php echo $row->relationship; ?></p>
                </div>
            </div>
        </div>
        <?php } ?>

    </div>
    <?php


    }

 
    // FUNCTION TO STORE THE PROFILE DETAILS INTO DATABASE
    public function store()
    {

    $this->form_validation->set_rules('name', 'name', 'required');
    $this->form_validation->set_rules('email', 'email', 'required');
    $this->form_validation->set_rules('qualification', 'qualification', 'required');
   

    if (!$this->form_validation->run()) {
        http_response_code(412);
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'error',
            'errors' => validation_errors()
        ]);
    } else {
        // Process image upload if a file is selected
        $image_name = '';
        if (!empty($_FILES['user_image']['name'])) {
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $this->load->library('upload', $config);

            if ($this->upload->do_upload('user_image')) {
                $image_data = $this->upload->data();
                $image_name = $image_data['file_name'];
            } else {
                http_response_code(500);
                header('Content-Type: application/json');
                echo json_encode([
                    'status' => 'error',
                    'message' => $this->upload->display_errors()
                ]);
                return;
            }
        }

        // Insert data into the database
        $data = [
            'name' => $this->input->post('name'),
            'email' => $this->input->post('email'),
            'contact' => $this->input->post('contact'),
            'qualification' => $this->input->post('qualification'),
            'department' => $this->input->post('department'),
            'location' => $this->input->post('location'),
            'doj' => $this->input->post('doj'),
            'employeelevel' => $this->input->post('employeelevel'),
            'gender' => $this->input->post('gender'),
            'marritalstatus' => $this->input->post('marritalstatus'),
            'nationality' => $this->input->post('nationality'),
            'experience' => $this->input->post('experience'),
            'emergencyname' => $this->input->post('emergencyname'),
            'emergencycontact' => $this->input->post('emergencycontact'),
            'relationship' => $this->input->post('relationship'),
            'reportingmanager' => $this->input->post('reportingmanager'),
            'assetid' => $this->input->post('assetid'),
            'assettype' => $this->input->post('assettype'),
            'image' => $image_name // Save the image name in the database
        ];

        $result = $this->User_model->store($data);

        if ($result) {
            header("Access-Control-Allow-Origin:*");
            header('Content-Type: application/json');
            echo json_encode(['status' => "success"]);
        } else {
            http_response_code(500);
            header('Content-Type: application/json');
            echo json_encode([
                'status' => 'error',
                'message' => 'Failed to store data'
            ]);
        }
    }
}

    

}
