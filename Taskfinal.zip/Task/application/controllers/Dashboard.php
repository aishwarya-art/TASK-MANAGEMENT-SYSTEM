<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
 
    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');
        $this->load->model('Login_model');
        $this->load->library("form_validation");
        $this->load->library('session');
        $this->load->library('form_validation');
        $this->load->model('Dashboard_model');
        if(!$this->session->userdata('id'))
        redirect('index.php/Login');
    }

 
    public function dashboard()
    {
        $userfname=$this->session->userdata('name','admin');
        $this->load->view("admin/dashboard",['name'=>$userfname]);
        
    }

    public function profile()
    {
        $userfname=$this->session->userdata('name');
        $this->load->view("theme/header",['name'=>$userfname]);
        $this->load->view("admin/profile");
    }
   
    public function calendar(){
        $userfname=$this->session->userdata('name');
        $this->load->view("theme/include",['name'=>$userfname]);
        $this->load->view("admin/calendar",['name'=>$userfname]);
    }

  
}
