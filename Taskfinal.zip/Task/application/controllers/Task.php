<?php
defined('BASEPATH') OR exit('No direct script access allowed');  
 class Task extends CI_Controller {  
     
      public function __construct() 
      {  
          parent::__construct(); 
          $this->load->library('form_validation');
          $this->load->library('session');
          $this->load->model('Task_model');
          header("HTTP/1.1 200 OK");
          header("Access-Control-Allow-Headers: Content-Type"); 
          if(!$this->session->userdata('id'))
          redirect('index.php/Login');
       } 

       //LOADS VIEW TASK PAGE
      function index()
      {   
           $userfname=$this->session->userdata('name');  
           $this->load->view('theme/include');
           $this->load->view('admin/task1',['name'=>$userfname] ); 
           header("Access-Control-Allow-Origin:*"); 
      }  

      //FETCH SIGNGLE USER TO UPDATE
      function fetch_user()
      {  
           $this->load->model("Task_model");  
           $fetch_data = $this->Task_model->make_datatables();  
           $data = array();  
           foreach($fetch_data as $row)  
           {   
                $sub_array = array();  
                $sub_array[] = $row->id;  
                $sub_array[] = $row->project; 
                $sub_array[] = $row->category;  
                $sub_array[] = $row->sdate;  
                $sub_array[] = $row->priority;  
                $sub_array[] = $row->name;  
                $sub_array[] = $row->assignedto; 
                $sub_array[] = $row->ddate;  
                $sub_array[] = $row->status;   
                 
                $sub_array[] = '<button type="button" name="update" id="'.$row->id.'" class="btn btn-warning btn-xs update">Update</button>';  
                $sub_array[] = '<button type="button" name="delete" id="'.$row->id.'" class="btn btn-danger btn-xs delete">Delete</button>';  
                $sub_array[] ='<button type="button" class="btn btn-success btn-xs mail" data-toggle="modal" data-target="#mymail">Mail</button>';
                $data[] = $sub_array;  
           }  
        
           $output = array(  
                "draw"                    =>     intval($_POST["draw"]),  
                "recordsTotal"          =>      $this->Task_model->get_all_data(),  
                "recordsFiltered"     =>     $this->Task_model->get_filtered_data(),  
                "data"                    =>     $data  
           );  
           header("Access-Control-Allow-Origin:*");
           echo json_encode($output);  
      } 
      
      
      //EDIT TASK
      function user_action()
      {  
          header("Access-Control-Allow-Origin:*"); 
           if($_POST['action'] == 'Add')  
           {  
                $insert_data = array(  
                    'project'          =>     $this->input->post('project'),  
                    'category'               =>     $this->input->post('category'), 
                    'sdate'          =>     $this->input->post('sdate'),  
                    'priority'               =>     $this->input->post('priority'), 
                    'name'          =>     $this->input->post('name'),  
                    'assignedto'               =>     $this->input->post('assignedto'), 
                    'ddate'          =>     $this->input->post('ddate'),  
                    'status'               =>     $this->input->post('status'), 
                );  
                $this->load->model('Task_model');  
                $this->Task_model->insert_crud($insert_data);  
                echo 'Data Inserted';  
           }  
           if($_POST["action"] == "Edit")   
           {  
                
                $updated_data = array(  
                     'project'          =>     $this->input->post('project'),  
                     'category'               =>     $this->input->post('category'), 
                     'sdate'          =>     $this->input->post('sdate'),  
                     'priority'               =>     $this->input->post('priority'), 
                     'name'          =>     $this->input->post('name'),  
                     'assignedto'               =>     $this->input->post('assignedto'), 
                     'ddate'          =>     $this->input->post('ddate'),  
                     'status'               =>     $this->input->post('status'),    
                );  
                $this->load->model('Task_model');  
                header("Access-Control-Allow-Origin:*");
                $this->Task_model->update_crud($this->input->post("user_id"), $updated_data);  
                echo 'Data Updated';  
           }  
      }  
      
      //FETCH SINGLE TASK
      function fetch_single_user()  
      {  
           $output = array();  
           $this->load->model("Task_model");  
           $data = $this->Task_model->fetch_single_user($_POST["user_id"]);  
           foreach($data as $row)  
           {  
                $output['project'] = $row->project;  
                $output['category'] = $row->category; 
                $output['sdate'] = $row->sdate;  
                $output['priority'] = $row->priority; 
                $output['name'] = $row->name;  
                $output['assignedto'] = $row->assignedto; 
                $output['ddate'] = $row->ddate;  
                $output['status'] = $row->status;  
                
           }  
           header("Access-Control-Allow-Origin:*");
           echo json_encode($output);  
      } 
      
  
      //DELETE TASK
     function deleterecords()
     {
          header("Access-Control-Allow-Origin:*");
          if ($this->input->post('type') == 2)
          {
               $id = $this->input->post('user_id');
               $this->load->model("Task_model");
               $result = $this->Task_model->deleterecords($id);

               if ($result) {
                    echo json_encode(array("statusCode" => 200, "message" => "Record Deleted Successfully"));
               } else {
                    echo json_encode(array("statusCode" => 400, "message" => "Error Deleting Record"));
               }
     }
}


     //ADD TASK TO DATABASE
     function add() 
     { 
  
     $this->load->library('form_validation');
     $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
     $this->form_validation->set_rules('project', 'project', 'required');
     $this->form_validation->set_rules('category', 'category', 'required');

     
     if ($this->form_validation->run() == FALSE) {
       
        $userfname=$this->session->userdata('name');
        $this->load->view('theme/include',['name'=>$userfname]);
     $this->load->view('admin/taskadd',['name'=>$userfname]);
  
     } 
     else { 
       
     $data = array(
    
            
               'project'          =>     $this->input->post('project'),  
               'category'               =>     $this->input->post('category'), 
               'sdate'          =>     $this->input->post('sdate'),  
               'priority'               =>     $this->input->post('priority'), 
               'name'          =>     $this->input->post('name'),  
               'assignedto'               =>     $this->input->post('assignedto'), 
               'ddate'          =>     $this->input->post('ddate'),  
               'status'               =>     $this->input->post('status') 
    
     
     );
     // echo "<pre>"; print_r($data);die();
   
     $this->Task_model->form_insert($data);
     $userfname=$this->session->userdata('name');
     $this->load->view('theme/include');
     $this->load->view('admin/taskadd',['name'=>$userfname]);
     }
     } 
     


//SEND MAIL NOTIDICATION FOR TASK ASSIGNED
public function sendmail()
{
      $email = $this->input->post('email');      
      $findemail = $this->Task_model->sendmail($email);  
      if($findemail){
       $this->Task_model->assignproject($findemail);        
        }else{
       $this->session->set_flashdata('error',' Email not found!');
       redirect('index.php/Task/index');
   }
}
 }