<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Logout extends CI_Controller {

    //Logout Functinality redirects to the login page,destroys session data.
    public function index()
    {
        $this->load->helper('url');
        $this->load->library('form_validation'); 
        $this->session->unset_userdata('id');
        $this->session->sess_destroy();
        redirect('index.php/Login');
    }
} 