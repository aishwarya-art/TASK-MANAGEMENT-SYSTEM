<?php
header('Access-Control-Allow-Origin: *');
class Ajax extends CI_Controller 
{ 
    //Store session name and redirects to login page,if not logged in.
    public function __construct()
    {   
        parent::__construct(); 
        $this->load->helper('url'); 
        $this->load->database();
        $this->load->model('Ajax_model');
        $userfname=$this->session->userdata('name');
        $this->load->library('pagination');
        header("HTTP/1.1 200 OK");
        header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE,OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type"); 
        if(!$this->session->userdata('id'))
        redirect('index.php/Login');
    }
    
 
    //loads the project view page
    function index()
    { 
        $userfname=$this->session->userdata('name');  
        $this->load->view('admin/newproject',['name'=>$userfname] ); 
        header("Access-Control-Allow-Origin:*"); 
    }  

    //display projects, added pagination,sort option and search using Ajax.
    function fetch_user()
    {  
       $this->load->model("Ajax_model");  
       $fetch_data = $this->Ajax_model->make_datatables();  
       $data = array();  
       foreach($fetch_data as $row)  
       {   
            $sub_array = array();  
            $sub_array[] = $row->id;  
            $sub_array[] = $row->title;  
            $sub_array[] = $row->phase;  
            $sub_array[] = $row->priority;  
            $sub_array[] = $row->status;  
            $sub_array[] = $row->details;  
             
            $sub_array[] = '<button type="button" name="update" id="'.$row->id.'" class="btn btn-warning btn-xs update">Update</button>';  
            $sub_array[] = '<button type="button" name="delete" id="'.$row->id.'" class="btn btn-danger btn-xs delete">Delete</button>';  
            $data[] = $sub_array;  
       }  
    
       $output = array(  
            "draw"                    =>     intval($_POST["draw"]),  
            "recordsTotal"          =>      $this->Ajax_model->get_all_data(),  
            "recordsFiltered"     =>     $this->Ajax_model->get_filtered_data(),  
            "data"                    =>     $data  
       );  
       header("Access-Control-Allow-Origin:*");
       echo json_encode($output);  
  } 

    //Update project data-Ajax
    function user_action(){  
      header("Access-Control-Allow-Origin:*"); 
       if($_POST["action"] == "Edit")   
       {  
            
            $updated_data = array(  
                 'title'          =>     $this->input->post('title'),  
                 'phase'               =>     $this->input->post('phase'), 
                 'priority'          =>     $this->input->post('priority'),  
                 'status'               =>     $this->input->post('status'), 
                 'details'          =>     $this->input->post('details'),  
                  
            );  
            $this->load->model('Ajax_model');  
            header("Access-Control-Allow-Origin:*");
            $this->Ajax_model->update_crud($this->input->post("user_id"), $updated_data);  
            echo 'Data Updated';  
       }  
  }  
  
  //fetch single user data while updating.Ajax
  function fetch_single_user()  
  {  
       $output = array();  
       $this->load->model("Ajax_model");  
       $data = $this->Ajax_model->fetch_single_user($_POST["user_id"]);  
       foreach($data as $row)  
       {  
            $output['title'] = $row->title;  
            $output['phase'] = $row->phase; 
            $output['priority'] = $row->priority;  
            $output['status'] = $row->status; 
            $output['details'] = $row->details;   
            
       }  
       header("Access-Control-Allow-Origin:*");
       echo json_encode($output);  
  } 
  

  //delete project record-Ajax
  function deleterecords()
  {
      header("Access-Control-Allow-Origin:*");
      if ($this->input->post('type') == 2)
      {
          $id = $this->input->post('user_id');
          $this->load->model("Ajax_model");
          $result = $this->Ajax_model->deleterecords($id);
  
          if ($result) {
              echo json_encode(array("statusCode" => 200, "message" => "Record Deleted Successfully"));
          } else {
              echo json_encode(array("statusCode" => 400, "message" => "Error Deleting Record"));
          }
      }
  }
  
  
  //Insert project into database, using normal php.
  function add() { 
    
       $this->load->library('form_validation');
       $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
       $this->form_validation->set_rules('title', 'title', 'required');
       $this->form_validation->set_rules('phase', 'phase', 'required');
      
       
       if ($this->form_validation->run() == FALSE) {
            $userfname=$this->session->userdata('name');
            $this->load->view('admin/projectadd',['name'=>$userfname]);
       } 
       else {
         
       $data = array(
      
              
                 'title'          =>     $this->input->post('title'),  
                 'phase'               =>     $this->input->post('phase'), 
                 'priority'          =>     $this->input->post('priority'),  
                 'status'               =>     $this->input->post('status'), 
                 'details'          =>     $this->input->post('details')  
                 
      
       
       );
       // echo "<pre>"; print_r($data);die();
     
       $this->Ajax_model->form_insert($data);
       $data['message'] = 'Data Inserted Successfully';
      
       redirect('index.php/Ajax/index');
       }
    } 
       
 
}
