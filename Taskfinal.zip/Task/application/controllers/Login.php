<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->helper('url'); 
        $this->load->model('Login_model');
        $this->load->library("form_validation");
       
    }
   
   //Login,checks if the account is registered or not.
    public function index() {
       
        $this->load->library('session');
        $this->load->library('form_validation'); 

        $this->form_validation->set_rules('email','email ','required|valid_email');
        $this->form_validation->set_rules('password','Password','required');

        if($this->form_validation->run()) {
            $email = $this->input->post('email');
            $password = md5($this->input->post('password'));

            $this->load->model('Login_model');
            $validate = $this->Login_model->index($email, $password);

            if($validate) {
                $this->session->set_userdata('id', $validate->id);  
                $this->session->set_userdata('name', $validate->name);
                $this->session->set_userdata('email', $validate->email);
                if($validate->role === 'admin') {
                    $this->session->set_userdata('role', 'admin');  
                     redirect('index.php/Dashboard/dashboard'); 
                   
                } else {
                    $this->session->set_userdata('role', 'student');  
                   
                     redirect('index.php/User/index'); 
                }
            } else {
                $this->session->set_flashdata('error', 'Invalid login details. Please try again.');
                redirect('index.php/Login');
            }
        } else {
            $this->load->view('login/login');    
        }
    }

   //Forgot Password,checks if the mail Id is already registered or not.
    public function ForgotPassword()
    {
        $email = $this->input->post('email');      
        $findemail = $this->Login_model->ForgotPassword($email);

        if($findemail)
        {
            $this->Login_model->sendpassword($findemail);        
        }
        else
        {
            $this->session->set_flashdata('error',' Email not found!');
            redirect('index.php/Login');
        }
    }
 
    //confirms the password for admin
    public function ConfirmPassword()
    {
        $password =md5($this->input->post('password'));      
        $findpassword = $this->Login_model->ConfirmPassword($password);

        if($findpassword){
            $this->Login_model->checkpassword($findpassword);        
        }
        else
        {
            $this->session->set_flashdata('error',' Incorrect Password!');
            redirect('index.php/Dashboard/dashboard');
        } 
    }
   
    //confirms the password for user
    public function ConfirmPass()
    {
        $password =md5($this->input->post('password'));      
        $findpassword = $this->Login_model->ConfirmPass($password); 

        if($findpassword){
                $this->Login_model->checkpass($findpassword);        
        }
        else
        {
            $this->session->set_flashdata('error',' Incorrect Password!');
            redirect('index.php/User/index');
        } 
    }

    //change password using the old password
    public function change_pass()
    {
        // Get input values
        $old_pass = md5($this->input->post('old_pass'));
        $new_pass = md5($this->input->post('new_pass'));
        $confirm_pass = md5($this->input->post('confirm_pass'));
        $email = $this->session->userdata('email');

        // Fetch the current password from the database
        $query = $this->db->query("SELECT password FROM account WHERE email='$email'");
        $row = $query->row();

        // Check if the old password matches the one in the database
        if ($row && $old_pass === $row->password) {
            // Check if the new password matches the confirmed password
            if ($new_pass === $confirm_pass) {
            // Update the password in the database
            $this->Login_model->change_pass($email, $new_pass);
            echo "Password changed successfully!";
            } else {
                echo "New password and confirmation do not match.";
            }
        } else {
                echo "Invalid old password.";
        }
        redirect('index.php/Dashboard/dashboard');
    }

}