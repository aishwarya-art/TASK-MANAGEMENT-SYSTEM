<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Account extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');
        $this->load->model('Account_model');
        $this->load->library("form_validation");
    }
    
    //Register new user to the application
    public function index()
    {
        $this->load->library('session');
        $this->load->library('form_validation'); 

        $this->form_validation->set_rules('name',' Name','required|alpha');
        $this->form_validation->set_rules('email','email','required|valid_email|is_unique[account.email]');
        $this->form_validation->set_rules('password','Password','required|min_length[6]');
        $this->form_validation->set_rules('confirmpassword','Confirm Password','required|min_length[6]|matches[password]');
        $this->form_validation->set_message('is_unique', 'This email already exists.');

        if($this->form_validation->run())
        { 
            $name = $this->input->post('name');
            $email = $this->input->post('email');
            $password = md5($this->input->post('password'));
			$role = $this->input->post('role');
             
            $this->load->model('Account_model');
            $this->Account_model->index($name, $email, $password, $role);
		}else{
            
            $this->load->view('login/account');
        }
    }
}