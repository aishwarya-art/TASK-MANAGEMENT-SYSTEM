<?php
class Profile_model extends CI_Model 
{
	//function to fetch user profile details when matched with session name
	function ajaxdisplay_records()
	{
        $userfname=$this->session->userdata('name');
		$query=$this->db->query("select * from profile where name=?",array('name'=>$userfname));
		return $query->result();
	}  

	//function to update user profile details
	function updaterecords($id, $paddress, $taddress)
	{
		$query="UPDATE `profile` 

		SET  
		`paddress`='$paddress',
		`taddress`='$taddress'
		
		
		 WHERE id=$id";
		$this->db->query($query);
	}

	//store profile details into database
	public function store($data)
	{
		return $this->db->insert('profile', $data);
	}
}