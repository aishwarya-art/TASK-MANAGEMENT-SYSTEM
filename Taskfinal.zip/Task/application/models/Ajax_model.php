<?php
class Ajax_model extends CI_Model 
{
  
	var $table = "project";  
	var $select_column = array("id", "title", "phase", "priority", "status", "details");  
	var $order_column = array("id", "title", "phase", "priority", "status", "details",null,null);  
	
	//search,sort option for tables
	function make_query()   
	{   
	   
		 $this->db->select($this->select_column);  
		 $this->db->from($this->table);  
		
		 if(isset($_POST["search"]["value"]))  
		 {  
			  $this->db->like("id", $_POST["search"]["value"]);  
			  $this->db->or_like("title", $_POST["search"]["value"]);  
			  $this->db->or_like("phase", $_POST["search"]["value"]);
			  $this->db->or_like("priority", $_POST["search"]["value"]);
			  $this->db->or_like("status", $_POST["search"]["value"]);
			  $this->db->or_like("details", $_POST["search"]["value"]);
			  
		 }  
		 if(isset($_POST["order"]))  
		 {  
			  $this->db->order_by($this->order_column[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);  
		 }   
		 else  
		 {   
			  $this->db->order_by('id', 'ASC');  
		 }  
	} 

	// create pagination limits.
	function make_datatables()
	{  
		 $this->make_query();  
		 if($_POST["length"] != -1)  
		 {  
			  $this->db->limit($_POST['length'], $_POST['start']);  
		 }  
		 $query = $this->db->get();  
		 return $query->result();  
	}  

	//display filtered data for search option
	function get_filtered_data()
	{  
		
		 $this->make_query();
		 $query = $this->db->get();  
		 return $query->num_rows();  
	}  

	//count the total no of projects from the database.
	function get_all_data()  
	{  	
		 $this->db->from($this->table);   
		 return $this->db->count_all_results();  
	} 

	//Get single user data from the database to update
	function fetch_single_user($user_id)  
	{  
		 $this->db->where("id", $user_id);  
		 $query=$this->db->get('project');  
		 return $query->result();  
	} 

	//update the user details in the datbase
	function update_crud($user_id, $data)  
	{  
		 $this->db->where("id", $user_id);  
		 $this->db->update("project", $data);  
	}
	
	//Delete the selected record
	function deleterecords($id)
	{
	
	$this->db->where('id', $id);
	$result = $this->db->delete('project');

		if ($result)
		{
			return true; 
		} 
		else
		 {
			$error = $this->db->error();
			log_message('error', 'Database Error: ' . $error['message']); 
			return false;  
		}
	}

	//Insert data into project table
	function form_insert($data)
	{
	
		$this->db->insert('project', $data);
		echo $this->db->last_query();
	}


}