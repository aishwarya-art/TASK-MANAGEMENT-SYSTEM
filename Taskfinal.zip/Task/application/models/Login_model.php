<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login_model extends CI_Model{


    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->library("form_validation");
    }

    //login into appliaction if,email registered.
    public function index($email,$password)
    {
        $data=array
        (
        'email'=>$email,
        'password'=>$password
        );

        $query=$this->db->where($data);
        $login=$this->db->get('account');

            if($login!=NULL){

                return $login->row();
            }  
        }

    //While forgot password,check if the email is registered    
    public function ForgotPassword($email)
    {
        $this->db->select('email');
        $this->db->from('account'); 
        $this->db->where('email', $email); 
        $query=$this->db->get();
        return $query->row_array();
    }

    //For registered email send OTP as the password to Login 
    //and send that OPT as the new password in the database.
    public function sendpassword($data)
    {
        $email = $data['email'];
        $query1=$this->db->query("SELECT *  from account where email = '".$email."' ");
        $row=$query1->result_array();
        if ($query1->num_rows()>0)
            
    {
        $passwordplain = "";
        $passwordplain  = rand(999999999,9999999999);
        $newpass['password'] = md5($passwordplain);
        $this->db->where('email', $email);
        $this->db->update('account', $newpass); 
        $mail_message='Dear '.$row[0]['name'].','. "\r\n";
        $mail_message.='Thanks for contacting regarding to forgot password,<br> Your <b>Password</b> is <b>'.$passwordplain.'</b>'."\r\n";
        $mail_message.='<br>Please Update your password.';
        $mail_message.='<br>Thanks & Regards';
        $mail_message.='<br>TechKshetra Info Solutions';        
        date_default_timezone_set('Etc/UTC');
    
        $this->load->library('phpmailer_lib');
        $mail = $this->phpmailer_lib->load();
        
        $mail->isSMTP();
        $mail->SMTPSecure = "tls"; 
        $mail->Debugoutput = 'html';
        $mail->Host = "smtp-relay.brevo.com";
        $mail->Port = 587;
        $mail->SMTPAuth = true;   
        $mail->Username = "aishwarya.ms661@gmail.com";    
        $mail->Password = "D8fORYWnzG4qxM1L";
        $mail->setFrom('aishwarya.ms661@gmail.com', 'admin');
        $mail->IsHTML(true);
        $mail->addAddress($email);
        $mail->Subject = 'OTP from company for new Password';
        $mail->Body    = $mail_message;
        $mail->AltBody = $mail_message;
        
        if (!$mail->send()) {
                $this->session->set_flashdata('error','Failed to send password, please try again!');
                redirect('index.php/Login');
        } else {
            $this->session->set_flashdata('msg','Password sent to your email!');
                redirect('index.php/Login');
        }
                redirect('index.php/Login');      
        }

        else
        {  
            $this->session->set_flashdata('error','Email not found try again!');
            redirect('index.php/Login');  
        }
    }
    
    //confirm password functinality for the account logged in.
    public function ConfirmPassword($password)
    {
            $this->db->select('password');
            $this->db->from('account'); 
            $this->db->where('password', $password); 
            $query=$this->db->get();
            return $query->row_array();
    }
 
    //check password confired for Admin.
    public function checkpassword($data)
    {

    $password = $data['password'];
    $query1=$this->db->query("SELECT *  from account where password = '".$password."' ");
    $row=$query1->result_array();
    if ($query1->num_rows()>0)
        {
            //  "password confirmed";
            redirect('index.php/Profile/ajaxmain');  
        }
    else{

        //  "check password again";
        redirect('index.php/Dashboard/dashboard');  
    }

    }

     //confirm password functinality for the account logged in.
    public function ConfirmPass($password)
    {
        $this->db->select('password');
        $this->db->from('account'); 
        $this->db->where('password', $password); 
        $query=$this->db->get();
        return $query->row_array();
    }

    //check password confired for User.
    public function checkpass($data)
    {

        $password = $data['password'];
        $query1=$this->db->query("SELECT *  from account where password = '".$password."' ");
        $row=$query1->result_array();
        if ($query1->num_rows()>0)
        {
            
            redirect('index.php/User/ajaxmain');  
        }
        else
        {

            redirect('index.php/User/index');  
        }

    }


    //change Password and update new password into database.
    public function change_pass($email, $new_pass)
    {
        $data = array
        (
            'password' => $new_pass
        );
        $this->db->where('email', $email);
        $this->db->update('account', $data);
        // Check if the update was successful
        if ($this->db->affected_rows() > 0) {
            return true; // Password updated successfully
        } else {
            return false; // Password update failed
        }
    }

}