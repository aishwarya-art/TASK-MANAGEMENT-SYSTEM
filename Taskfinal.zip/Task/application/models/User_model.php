<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class User_model extends CI_Model
{
    public function __construct() 
    {
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->library("form_validation");
    }
 
    //function to the tasks only that are assigned to the specifc user 
    function tasks() 
	{
        $userfname=$this->session->userdata('name');
		$query=$this->db->query("select * from assign where name=?",array('name'=>$userfname));
		return $query->result();
	}

     //function to updater task status by usr,and store it in database
     function updaterecords($id,$status)
	{
		$query="UPDATE `assign` 
  
		SET 
         `status`='$status'
		 WHERE id=$id ";
		
		 return $this->db->query($query);
		
	}

     //function to display profile details when matching with session name
    function ajaxdisplay_records()
     {
        $userfname=$this->session->userdata('name');
		$query=$this->db->query("select * from profile where name=?",array('name'=>$userfname));
		return $query->result();
	}
 
     //store profile details into the database
     public function store($data)
     {

     return $this->db->insert('profile', $data);

     }

     //get totl projects from the projects table,add pagination, sort, search option
     var $table = "project";  
      var $select_column = array("id", "title", "phase", "priority", "status", "details");  
      var $order_column = array("id", "title", "phase", "priority", "status", "details");  
      

      function make_query()   
      {  
           $this->db->select($this->select_column);  
           $this->db->from($this->table);  
           if(isset($_POST["search"]["value"]))  
           {  
                $this->db->like("id", $_POST["search"]["value"]);  
                $this->db->or_like("title", $_POST["search"]["value"]);
                $this->db->or_like("phase", $_POST["search"]["value"]);
                $this->db->or_like("priority", $_POST["search"]["value"]);
                $this->db->or_like("status", $_POST["search"]["value"]);
                $this->db->or_like("details", $_POST["search"]["value"]);  
           }  
           if(isset($_POST["order"]))  
           {  
                $this->db->order_by($this->order_column[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);  
           }   
           else  
           {   
                $this->db->order_by('id', 'ASC');  
           }  
      }  

      //limit the length of the data by using pagination and display records
      function make_datatables()
      {  
           $this->make_query();  
           if($_POST["length"] != -1)  
           {  
                $this->db->limit($_POST['length'], $_POST['start']);  
           }  
           $query = $this->db->get();  
           return $query->result();  
      } 
      
      //display the searched data 
      function get_filtered_data()
      {  
           $this->make_query();  
           $query = $this->db->get();  
           return $query->num_rows();  
      }  
      
      //count the no of projects
      function get_all_data()  
      {  
           $this->db->select("*");  
           $this->db->from($this->table);  
           return $this->db->count_all_results();  
      }  
     




}