<?php
class Task_model extends CI_Model  
 {    
      var $table = "assign";  
      var $select_column = array("id", "project", "category", "sdate", "priority", "name", "assignedto", "ddate", "status");  
      var $order_column = array("id", "project", "category", "sdate", "priority", "name", "assignedto", "ddate", "status", null,null,null);  
      
      function make_query()   
      {   
         
           $this->db->select($this->select_column);  
           $this->db->from($this->table);  
          
           if(isset($_POST["search"]["value"]))   
           {  
                $this->db->like("id", $_POST["search"]["value"]);  
                $this->db->or_like("project", $_POST["search"]["value"]);  
                $this->db->or_like("category", $_POST["search"]["value"]);
                $this->db->or_like("priority", $_POST["search"]["value"]);
                $this->db->or_like("sdate", $_POST["search"]["value"]);
                $this->db->or_like("name", $_POST["search"]["value"]);
                $this->db->or_like("assignedto", $_POST["search"]["value"]);
                $this->db->or_like("ddate", $_POST["search"]["value"]);
                $this->db->or_like("status", $_POST["search"]["value"]);
           }  
           if(isset($_POST["order"]))  
           {  
                $this->db->order_by($this->order_column[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);  
           }   
           else  
           {   
                $this->db->order_by('id', 'ASC');  
           }  
      } 
      
      
      function make_datatables(){  
           $this->make_query();  
           if($_POST["length"] != -1)  
           {  
                $this->db->limit($_POST['length'], $_POST['start']);  
           }  
           $query = $this->db->get();  
           return $query->result();  
      }  

      function get_filtered_data(){  
          
          
           $this->make_query();
           $query = $this->db->get();  
           return $query->num_rows();  
      }
      
      
      function get_all_data()  
      {  
        $userfname=$this->session->userdata('name');
           //$this->db->select("*");
          
           $this->db->from($this->table);  
          // $this->db->where('name','user');  
           return $this->db->count_all_results();  
      } 
      
      
      function insert_crud($data)  
      {  
           $this->db->insert('assign', $data);  
      } 
      
      
      function fetch_single_user($user_id)  
      {  
           $this->db->where("id", $user_id);  
           $query=$this->db->get('assign');  
           return $query->result();  
      } 
      
      
      function update_crud($user_id, $data)  
      {  
           $this->db->where("id", $user_id);  
           $this->db->update("assign", $data);  
      }
    

     function deleterecords($id)
     {
          $this->db->where('id', $id);
          $result = $this->db->delete('assign');

          if ($result) {
               return true; // Record deleted successfully
          } else {
               $error = $this->db->error();
               log_message('error', 'Database Error: ' . $error['message']); // Log the error
               return false;  // Error deleting record
          }
     }

     
     function form_insert($data)
     {
          $this->db->insert('assign', $data);
          return $this->db->last_query();
          }




     public function sendmail($email)
     {
          $this->db->select('email');
          $this->db->from('account'); 
          $this->db->where('email', $email); 
          $query=$this->db->get();
          return $query->row_array();
     }



public function assignproject($data)
{
        $email = $data['email'];
        $query1=$this->db->query("SELECT *  from account where email = '".$email."' ");
        $row=$query1->result_array();
        if ($query1->num_rows()>0)
      
{
        
        $mail_message='Dear '.$row[0]['name'].','. "\r\n";
        $mail_message.='Hope, you are doing well<br> <b>New Task is assigned to you by admin.</b>,Check on the details and complete the project on time'."\r\n";
        $mail_message.='<br>Best Of Luck.';
        $mail_message.='<br>Thanks & Regards';
        $mail_message.='<br>TechKshetra Info Solutions';        
        date_default_timezone_set('Etc/UTC');
    
        $this->load->library('phpmailer_lib');
        $mail = $this->phpmailer_lib->load();
        
        $mail->isSMTP();
        $mail->SMTPSecure = "tls"; 
        $mail->Debugoutput = 'html';
        $mail->Host = "smtp-relay.brevo.com";
        $mail->Port = 587;
        $mail->SMTPAuth = true;   
        $mail->Username = "aishwarya.ms661@gmail.com";    
        $mail->Password = "D8fORYWnzG4qxM1L";
        $mail->setFrom('aishwarya.ms661@gmail.com', 'admin');
        $mail->IsHTML(true);
        $mail->addAddress($email);
        $mail->Subject = 'New Task Assigned';
        $mail->Body    = $mail_message;
        $mail->AltBody = $mail_message;
         
         if (!$mail->send()) {
                 $this->session->set_flashdata('error','Failed to send mail notification,try again!');
                 redirect('index.php/Task/index');
         } else {
             $this->session->set_flashdata('msg','Mail notification sent successfully!');
               redirect('index.php/Task/index');
         }
               redirect('index.php/Task/index');     
         }

         else
         {  
             $this->session->set_flashdata('error','Email not found try again!');
             rredirect('index.php/Task/index'); 
         }
         }

 }  