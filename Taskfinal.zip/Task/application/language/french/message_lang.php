<?php
$lang['welcome_message'] = 'salut Aishwarya, comment vas-tu ?';