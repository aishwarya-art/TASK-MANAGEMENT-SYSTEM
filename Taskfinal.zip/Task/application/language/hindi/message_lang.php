<?php
$lang['welcome_message'] = 'हे ऐश्वर्या, आप कैसी हैं?';