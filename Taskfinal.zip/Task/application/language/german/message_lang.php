<?php
$lang['welcome_message'] = 'Hey Aishwarya, wie geht es dir?';